This is the original project where the idea and features derived from.
Some features may not work in this project as it has not been modified since the WPF version started.