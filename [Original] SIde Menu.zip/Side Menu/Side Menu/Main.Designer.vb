﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.PanelMain = New System.Windows.Forms.Panel()
        Me.FlatButton12 = New Side_Menu.FlatButton()
        Me.FlatButton6 = New Side_Menu.FlatButton()
        Me.FlatButton5 = New Side_Menu.FlatButton()
        Me.FlatButton4 = New Side_Menu.FlatButton()
        Me.FlatButton3 = New Side_Menu.FlatButton()
        Me.FlatButton2 = New Side_Menu.FlatButton()
        Me.FlatButton1 = New Side_Menu.FlatButton()
        Me.PanelCMD = New System.Windows.Forms.Panel()
        Me.FlatButton10 = New Side_Menu.FlatButton()
        Me.FlatButton9 = New Side_Menu.FlatButton()
        Me.FlatTextBox1 = New Side_Menu.FlatTextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.UpdateTime = New System.Windows.Forms.Timer(Me.components)
        Me.PanelWidget = New System.Windows.Forms.Panel()
        Me.FlatButton7 = New Side_Menu.FlatButton()
        Me.FlatButton8 = New Side_Menu.FlatButton()
        Me.FlatButton11 = New Side_Menu.FlatButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PanelMemo = New System.Windows.Forms.Panel()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.PanelNetworkTools = New System.Windows.Forms.Panel()
        Me.FlatLabel14 = New Side_Menu.FlatLabel()
        Me.FlatCheckBox1 = New Side_Menu.FlatCheckBox()
        Me.FlatButton13 = New Side_Menu.FlatButton()
        Me.FlatButton14 = New Side_Menu.FlatButton()
        Me.FlatButton15 = New Side_Menu.FlatButton()
        Me.FlatButton16 = New Side_Menu.FlatButton()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.FlatTextBox4 = New Side_Menu.FlatTextBox()
        Me.FlatTextBox3 = New Side_Menu.FlatTextBox()
        Me.FlatLabel13 = New Side_Menu.FlatLabel()
        Me.FlatButton17 = New Side_Menu.FlatButton()
        Me.FlatTextBox2 = New Side_Menu.FlatTextBox()
        Me.FlatTextBox5 = New Side_Menu.FlatTextBox()
        Me.FlatLabel12 = New Side_Menu.FlatLabel()
        Me.ScanAllPorts = New System.ComponentModel.BackgroundWorker()
        Me.SinglePortScan = New System.ComponentModel.BackgroundWorker()
        Me.PanelSystemInfo = New System.Windows.Forms.Panel()
        Me.FlatButton18 = New Side_Menu.FlatButton()
        Me.FlatLabel27 = New Side_Menu.FlatLabel()
        Me.FlatTextBox16 = New Side_Menu.FlatTextBox()
        Me.FlatLabel26 = New Side_Menu.FlatLabel()
        Me.FlatTextBox15 = New Side_Menu.FlatTextBox()
        Me.FlatLabel25 = New Side_Menu.FlatLabel()
        Me.FlatTextBox14 = New Side_Menu.FlatTextBox()
        Me.FlatLabel24 = New Side_Menu.FlatLabel()
        Me.FlatTextBox13 = New Side_Menu.FlatTextBox()
        Me.FlatLabel23 = New Side_Menu.FlatLabel()
        Me.FlatTextBox12 = New Side_Menu.FlatTextBox()
        Me.FlatLabel22 = New Side_Menu.FlatLabel()
        Me.FlatTextBox11 = New Side_Menu.FlatTextBox()
        Me.FlatLabel21 = New Side_Menu.FlatLabel()
        Me.FlatTextBox10 = New Side_Menu.FlatTextBox()
        Me.FlatLabel20 = New Side_Menu.FlatLabel()
        Me.FlatTextBox9 = New Side_Menu.FlatTextBox()
        Me.FlatLabel19 = New Side_Menu.FlatLabel()
        Me.FlatTextBox8 = New Side_Menu.FlatTextBox()
        Me.FlatLabel18 = New Side_Menu.FlatLabel()
        Me.FlatTextBox7 = New Side_Menu.FlatTextBox()
        Me.FlatLabel17 = New Side_Menu.FlatLabel()
        Me.FlatTextBox6 = New Side_Menu.FlatTextBox()
        Me.FlatLabel16 = New Side_Menu.FlatLabel()
        Me.FlatTextBox20 = New Side_Menu.FlatTextBox()
        Me.FlatLabel15 = New Side_Menu.FlatLabel()
        Me.FlatTextBox21 = New Side_Menu.FlatTextBox()
        Me.FlatLabel1 = New Side_Menu.FlatLabel()
        Me.FlatTextBox22 = New Side_Menu.FlatTextBox()
        Me.FlatLabel2 = New Side_Menu.FlatLabel()
        Me.FlatTextBox23 = New Side_Menu.FlatTextBox()
        Me.FlatLabel3 = New Side_Menu.FlatLabel()
        Me.FlatTextBox24 = New Side_Menu.FlatTextBox()
        Me.PanelVT = New System.Windows.Forms.Panel()
        Me.FlatButton29 = New Side_Menu.FlatButton()
        Me.Menu_VTData = New Side_Menu.FlatContextMenuStrip()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FlatButton28 = New Side_Menu.FlatButton()
        Me.Menu_VTScan = New Side_Menu.FlatContextMenuStrip()
        Me.ViewReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewReportToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RescanHashToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AllProcessesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FlatListBox1 = New Side_Menu.FlatListBox()
        Me.FlatButton23 = New Side_Menu.FlatButton()
        Me.FlatLabel5 = New Side_Menu.FlatLabel()
        Me.FlatTextBox18 = New Side_Menu.FlatTextBox()
        Me.FlatLabel4 = New Side_Menu.FlatLabel()
        Me.FlatTextBox17 = New Side_Menu.FlatTextBox()
        Me.FlatButton19 = New Side_Menu.FlatButton()
        Me.VT_FileSelect = New System.Windows.Forms.OpenFileDialog()
        Me.PanelSettings = New System.Windows.Forms.Panel()
        Me.FlatCheckBox4 = New Side_Menu.FlatCheckBox()
        Me.FlatCheckBox3 = New Side_Menu.FlatCheckBox()
        Me.FlatLabel28 = New Side_Menu.FlatLabel()
        Me.FlatLabel29 = New Side_Menu.FlatLabel()
        Me.FlatLabel7 = New Side_Menu.FlatLabel()
        Me.FlatLabel8 = New Side_Menu.FlatLabel()
        Me.FlatLabel9 = New Side_Menu.FlatLabel()
        Me.FlatLabel10 = New Side_Menu.FlatLabel()
        Me.FlatLabel11 = New Side_Menu.FlatLabel()
        Me.FlatLabel30 = New Side_Menu.FlatLabel()
        Me.FlatLabel31 = New Side_Menu.FlatLabel()
        Me.FlatLabel32 = New Side_Menu.FlatLabel()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.FlatLabel33 = New Side_Menu.FlatLabel()
        Me.FlatLabel34 = New Side_Menu.FlatLabel()
        Me.FlatLabel35 = New Side_Menu.FlatLabel()
        Me.FlatLabel36 = New Side_Menu.FlatLabel()
        Me.FlatLabel37 = New Side_Menu.FlatLabel()
        Me.FlatLabel38 = New Side_Menu.FlatLabel()
        Me.FlatLabel39 = New Side_Menu.FlatLabel()
        Me.FlatLabel40 = New Side_Menu.FlatLabel()
        Me.FlatCheckBox2 = New Side_Menu.FlatCheckBox()
        Me.FlatButton27 = New Side_Menu.FlatButton()
        Me.TTcolour = New Side_Menu.FlatButton()
        Me.TBcolour = New Side_Menu.FlatButton()
        Me.Lcolour = New Side_Menu.FlatButton()
        Me.BTcolour = New Side_Menu.FlatButton()
        Me.Pcolour = New Side_Menu.FlatButton()
        Me.BGcolour = New Side_Menu.FlatButton()
        Me.StayActive = New Side_Menu.FlatCheckBox()
        Me.Time = New Side_Menu.FlatLabel()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.Menu_Icon = New Side_Menu.FlatContextMenuStrip()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PanelMain.SuspendLayout()
        Me.PanelCMD.SuspendLayout()
        Me.PanelWidget.SuspendLayout()
        Me.PanelMemo.SuspendLayout()
        Me.PanelNetworkTools.SuspendLayout()
        Me.PanelSystemInfo.SuspendLayout()
        Me.PanelVT.SuspendLayout()
        Me.Menu_VTData.SuspendLayout()
        Me.Menu_VTScan.SuspendLayout()
        Me.PanelSettings.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Menu_Icon.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelMain
        '
        Me.PanelMain.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelMain.AutoScroll = True
        Me.PanelMain.Controls.Add(Me.FlatButton12)
        Me.PanelMain.Controls.Add(Me.FlatButton6)
        Me.PanelMain.Controls.Add(Me.FlatButton5)
        Me.PanelMain.Controls.Add(Me.FlatButton4)
        Me.PanelMain.Controls.Add(Me.FlatButton3)
        Me.PanelMain.Controls.Add(Me.FlatButton2)
        Me.PanelMain.Controls.Add(Me.FlatButton1)
        Me.PanelMain.Location = New System.Drawing.Point(12, 43)
        Me.PanelMain.Name = "PanelMain"
        Me.PanelMain.Size = New System.Drawing.Size(327, 474)
        Me.PanelMain.TabIndex = 1
        '
        'FlatButton12
        '
        Me.FlatButton12.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton12.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton12.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton12.Location = New System.Drawing.Point(221, 112)
        Me.FlatButton12.Name = "FlatButton12"
        Me.FlatButton12.Rounded = False
        Me.FlatButton12.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton12.TabIndex = 6
        Me.FlatButton12.Text = "VirusTotal Scan"
        Me.FlatButton12.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton6
        '
        Me.FlatButton6.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton6.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton6.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton6.Location = New System.Drawing.Point(3, 221)
        Me.FlatButton6.Name = "FlatButton6"
        Me.FlatButton6.Rounded = False
        Me.FlatButton6.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton6.TabIndex = 5
        Me.FlatButton6.Text = "Settings"
        Me.FlatButton6.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton5
        '
        Me.FlatButton5.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton5.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton5.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton5.Location = New System.Drawing.Point(112, 112)
        Me.FlatButton5.Name = "FlatButton5"
        Me.FlatButton5.Rounded = False
        Me.FlatButton5.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton5.TabIndex = 4
        Me.FlatButton5.Text = "System Info"
        Me.FlatButton5.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton4
        '
        Me.FlatButton4.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton4.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton4.Location = New System.Drawing.Point(3, 112)
        Me.FlatButton4.Name = "FlatButton4"
        Me.FlatButton4.Rounded = False
        Me.FlatButton4.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton4.TabIndex = 3
        Me.FlatButton4.Text = "Network Tools"
        Me.FlatButton4.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton3
        '
        Me.FlatButton3.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton3.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton3.Location = New System.Drawing.Point(221, 3)
        Me.FlatButton3.Name = "FlatButton3"
        Me.FlatButton3.Rounded = False
        Me.FlatButton3.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton3.TabIndex = 2
        Me.FlatButton3.Text = "Memo"
        Me.FlatButton3.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton2
        '
        Me.FlatButton2.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton2.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton2.Location = New System.Drawing.Point(112, 3)
        Me.FlatButton2.Name = "FlatButton2"
        Me.FlatButton2.Rounded = False
        Me.FlatButton2.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton2.TabIndex = 1
        Me.FlatButton2.Text = "CMD"
        Me.FlatButton2.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton1
        '
        Me.FlatButton1.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton1.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton1.Location = New System.Drawing.Point(3, 3)
        Me.FlatButton1.Name = "FlatButton1"
        Me.FlatButton1.Rounded = False
        Me.FlatButton1.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton1.TabIndex = 0
        Me.FlatButton1.Text = "Widgets"
        Me.FlatButton1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'PanelCMD
        '
        Me.PanelCMD.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelCMD.AutoScroll = True
        Me.PanelCMD.Controls.Add(Me.FlatButton10)
        Me.PanelCMD.Controls.Add(Me.FlatButton9)
        Me.PanelCMD.Controls.Add(Me.FlatTextBox1)
        Me.PanelCMD.Controls.Add(Me.RichTextBox1)
        Me.PanelCMD.Location = New System.Drawing.Point(12, 43)
        Me.PanelCMD.Name = "PanelCMD"
        Me.PanelCMD.Size = New System.Drawing.Size(427, 474)
        Me.PanelCMD.TabIndex = 12
        Me.PanelCMD.Visible = False
        '
        'FlatButton10
        '
        Me.FlatButton10.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatButton10.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton10.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton10.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton10.Location = New System.Drawing.Point(318, 439)
        Me.FlatButton10.Name = "FlatButton10"
        Me.FlatButton10.Rounded = False
        Me.FlatButton10.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton10.TabIndex = 273
        Me.FlatButton10.Text = "Send"
        Me.FlatButton10.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton9
        '
        Me.FlatButton9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.FlatButton9.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton9.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton9.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton9.Location = New System.Drawing.Point(3, 439)
        Me.FlatButton9.Name = "FlatButton9"
        Me.FlatButton9.Rounded = False
        Me.FlatButton9.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton9.TabIndex = 272
        Me.FlatButton9.Text = "Clear"
        Me.FlatButton9.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatTextBox1
        '
        Me.FlatTextBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatTextBox1.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox1.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox1.Location = New System.Drawing.Point(3, 404)
        Me.FlatTextBox1.MaxLength = 32767
        Me.FlatTextBox1.Multiline = True
        Me.FlatTextBox1.Name = "FlatTextBox1"
        Me.FlatTextBox1.ReadOnly = False
        Me.FlatTextBox1.Size = New System.Drawing.Size(422, 29)
        Me.FlatTextBox1.TabIndex = 0
        Me.FlatTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox1.UseSystemPasswordChar = False
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.ForeColor = System.Drawing.Color.Silver
        Me.RichTextBox1.Location = New System.Drawing.Point(3, 3)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.RichTextBox1.Size = New System.Drawing.Size(421, 395)
        Me.RichTextBox1.TabIndex = 271
        Me.RichTextBox1.Text = ""
        '
        'UpdateTime
        '
        Me.UpdateTime.Enabled = True
        '
        'PanelWidget
        '
        Me.PanelWidget.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelWidget.AutoScroll = True
        Me.PanelWidget.Controls.Add(Me.FlatButton7)
        Me.PanelWidget.Controls.Add(Me.FlatButton8)
        Me.PanelWidget.Controls.Add(Me.FlatButton11)
        Me.PanelWidget.Location = New System.Drawing.Point(12, 43)
        Me.PanelWidget.Name = "PanelWidget"
        Me.PanelWidget.Size = New System.Drawing.Size(326, 474)
        Me.PanelWidget.TabIndex = 5
        Me.PanelWidget.Visible = False
        '
        'FlatButton7
        '
        Me.FlatButton7.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton7.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton7.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton7.Location = New System.Drawing.Point(112, 3)
        Me.FlatButton7.Name = "FlatButton7"
        Me.FlatButton7.Rounded = False
        Me.FlatButton7.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton7.TabIndex = 4
        Me.FlatButton7.Text = "System Info"
        Me.FlatButton7.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton8
        '
        Me.FlatButton8.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton8.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton8.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton8.Location = New System.Drawing.Point(221, 3)
        Me.FlatButton8.Name = "FlatButton8"
        Me.FlatButton8.Rounded = False
        Me.FlatButton8.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton8.TabIndex = 3
        Me.FlatButton8.Text = "Currency"
        Me.FlatButton8.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton11
        '
        Me.FlatButton11.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton11.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton11.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton11.Location = New System.Drawing.Point(3, 3)
        Me.FlatButton11.Name = "FlatButton11"
        Me.FlatButton11.Rounded = False
        Me.FlatButton11.Size = New System.Drawing.Size(103, 103)
        Me.FlatButton11.TabIndex = 0
        Me.FlatButton11.Text = "Web Browser"
        Me.FlatButton11.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'PanelMemo
        '
        Me.PanelMemo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelMemo.AutoScroll = True
        Me.PanelMemo.Controls.Add(Me.RichTextBox2)
        Me.PanelMemo.Location = New System.Drawing.Point(12, 43)
        Me.PanelMemo.Name = "PanelMemo"
        Me.PanelMemo.Size = New System.Drawing.Size(327, 474)
        Me.PanelMemo.TabIndex = 13
        Me.PanelMemo.Visible = False
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.RichTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox2.ForeColor = System.Drawing.Color.Silver
        Me.RichTextBox2.Location = New System.Drawing.Point(3, 3)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(320, 460)
        Me.RichTextBox2.TabIndex = 13
        Me.RichTextBox2.Text = ""
        '
        'PanelNetworkTools
        '
        Me.PanelNetworkTools.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelNetworkTools.AutoScroll = True
        Me.PanelNetworkTools.Controls.Add(Me.FlatLabel14)
        Me.PanelNetworkTools.Controls.Add(Me.FlatCheckBox1)
        Me.PanelNetworkTools.Controls.Add(Me.FlatButton13)
        Me.PanelNetworkTools.Controls.Add(Me.FlatButton14)
        Me.PanelNetworkTools.Controls.Add(Me.FlatButton15)
        Me.PanelNetworkTools.Controls.Add(Me.FlatButton16)
        Me.PanelNetworkTools.Controls.Add(Me.ListBox1)
        Me.PanelNetworkTools.Controls.Add(Me.FlatTextBox4)
        Me.PanelNetworkTools.Controls.Add(Me.FlatTextBox3)
        Me.PanelNetworkTools.Controls.Add(Me.FlatLabel13)
        Me.PanelNetworkTools.Controls.Add(Me.FlatButton17)
        Me.PanelNetworkTools.Controls.Add(Me.FlatTextBox2)
        Me.PanelNetworkTools.Controls.Add(Me.FlatTextBox5)
        Me.PanelNetworkTools.Controls.Add(Me.FlatLabel12)
        Me.PanelNetworkTools.Location = New System.Drawing.Point(12, 43)
        Me.PanelNetworkTools.Name = "PanelNetworkTools"
        Me.PanelNetworkTools.Size = New System.Drawing.Size(327, 474)
        Me.PanelNetworkTools.TabIndex = 14
        Me.PanelNetworkTools.Visible = False
        '
        'FlatLabel14
        '
        Me.FlatLabel14.AutoSize = True
        Me.FlatLabel14.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel14.ForeColor = System.Drawing.Color.White
        Me.FlatLabel14.Location = New System.Drawing.Point(9, 279)
        Me.FlatLabel14.Name = "FlatLabel14"
        Me.FlatLabel14.Size = New System.Drawing.Size(60, 13)
        Me.FlatLabel14.TabIndex = 13
        Me.FlatLabel14.Text = "Status: Idle"
        '
        'FlatCheckBox1
        '
        Me.FlatCheckBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox1.Checked = False
        Me.FlatCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.FlatCheckBox1.Location = New System.Drawing.Point(241, 254)
        Me.FlatCheckBox1.Name = "FlatCheckBox1"
        Me.FlatCheckBox1.Options = Side_Menu.FlatCheckBox._Options.Style1
        Me.FlatCheckBox1.Size = New System.Drawing.Size(82, 22)
        Me.FlatCheckBox1.TabIndex = 12
        Me.FlatCheckBox1.Text = "Full Scan"
        Me.FlatCheckBox1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton13
        '
        Me.FlatButton13.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton13.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton13.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton13.Location = New System.Drawing.Point(241, 214)
        Me.FlatButton13.Name = "FlatButton13"
        Me.FlatButton13.Rounded = False
        Me.FlatButton13.Size = New System.Drawing.Size(83, 29)
        Me.FlatButton13.TabIndex = 11
        Me.FlatButton13.Text = "Clear"
        Me.FlatButton13.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton14
        '
        Me.FlatButton14.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton14.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton14.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton14.Location = New System.Drawing.Point(241, 179)
        Me.FlatButton14.Name = "FlatButton14"
        Me.FlatButton14.Rounded = False
        Me.FlatButton14.Size = New System.Drawing.Size(83, 29)
        Me.FlatButton14.TabIndex = 10
        Me.FlatButton14.Text = "Copy"
        Me.FlatButton14.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton15
        '
        Me.FlatButton15.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton15.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton15.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton15.Location = New System.Drawing.Point(241, 144)
        Me.FlatButton15.Name = "FlatButton15"
        Me.FlatButton15.Rounded = False
        Me.FlatButton15.Size = New System.Drawing.Size(83, 29)
        Me.FlatButton15.TabIndex = 9
        Me.FlatButton15.Text = "Stop"
        Me.FlatButton15.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton16
        '
        Me.FlatButton16.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton16.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton16.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton16.Location = New System.Drawing.Point(241, 109)
        Me.FlatButton16.Name = "FlatButton16"
        Me.FlatButton16.Rounded = False
        Me.FlatButton16.Size = New System.Drawing.Size(83, 29)
        Me.FlatButton16.TabIndex = 8
        Me.FlatButton16.Text = "Start"
        Me.FlatButton16.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(6, 142)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(229, 134)
        Me.ListBox1.TabIndex = 7
        '
        'FlatTextBox4
        '
        Me.FlatTextBox4.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox4.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox4.Location = New System.Drawing.Point(171, 109)
        Me.FlatTextBox4.MaxLength = 32767
        Me.FlatTextBox4.Multiline = False
        Me.FlatTextBox4.Name = "FlatTextBox4"
        Me.FlatTextBox4.ReadOnly = False
        Me.FlatTextBox4.Size = New System.Drawing.Size(64, 29)
        Me.FlatTextBox4.TabIndex = 6
        Me.FlatTextBox4.Text = "Port"
        Me.FlatTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox4.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox4.UseSystemPasswordChar = False
        '
        'FlatTextBox3
        '
        Me.FlatTextBox3.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox3.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox3.Location = New System.Drawing.Point(6, 109)
        Me.FlatTextBox3.MaxLength = 32767
        Me.FlatTextBox3.Multiline = False
        Me.FlatTextBox3.Name = "FlatTextBox3"
        Me.FlatTextBox3.ReadOnly = False
        Me.FlatTextBox3.Size = New System.Drawing.Size(159, 29)
        Me.FlatTextBox3.TabIndex = 5
        Me.FlatTextBox3.Text = "IP Only"
        Me.FlatTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox3.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox3.UseSystemPasswordChar = False
        '
        'FlatLabel13
        '
        Me.FlatLabel13.AutoSize = True
        Me.FlatLabel13.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel13.ForeColor = System.Drawing.Color.White
        Me.FlatLabel13.Location = New System.Drawing.Point(3, 93)
        Me.FlatLabel13.Name = "FlatLabel13"
        Me.FlatLabel13.Size = New System.Drawing.Size(57, 13)
        Me.FlatLabel13.TabIndex = 4
        Me.FlatLabel13.Text = "Port Scan:"
        '
        'FlatButton17
        '
        Me.FlatButton17.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton17.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton17.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton17.Location = New System.Drawing.Point(241, 51)
        Me.FlatButton17.Name = "FlatButton17"
        Me.FlatButton17.Rounded = False
        Me.FlatButton17.Size = New System.Drawing.Size(83, 29)
        Me.FlatButton17.TabIndex = 3
        Me.FlatButton17.Text = "Get IP"
        Me.FlatButton17.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatTextBox2
        '
        Me.FlatTextBox2.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox2.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox2.Location = New System.Drawing.Point(6, 51)
        Me.FlatTextBox2.MaxLength = 32767
        Me.FlatTextBox2.Multiline = False
        Me.FlatTextBox2.Name = "FlatTextBox2"
        Me.FlatTextBox2.ReadOnly = False
        Me.FlatTextBox2.Size = New System.Drawing.Size(229, 29)
        Me.FlatTextBox2.TabIndex = 2
        Me.FlatTextBox2.Text = "IP Address"
        Me.FlatTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox2.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox2.UseSystemPasswordChar = False
        '
        'FlatTextBox5
        '
        Me.FlatTextBox5.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox5.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox5.Location = New System.Drawing.Point(6, 16)
        Me.FlatTextBox5.MaxLength = 32767
        Me.FlatTextBox5.Multiline = False
        Me.FlatTextBox5.Name = "FlatTextBox5"
        Me.FlatTextBox5.ReadOnly = False
        Me.FlatTextBox5.Size = New System.Drawing.Size(318, 29)
        Me.FlatTextBox5.TabIndex = 1
        Me.FlatTextBox5.Text = "DNS"
        Me.FlatTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox5.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox5.UseSystemPasswordChar = False
        '
        'FlatLabel12
        '
        Me.FlatLabel12.AutoSize = True
        Me.FlatLabel12.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel12.ForeColor = System.Drawing.Color.White
        Me.FlatLabel12.Location = New System.Drawing.Point(3, 0)
        Me.FlatLabel12.Name = "FlatLabel12"
        Me.FlatLabel12.Size = New System.Drawing.Size(62, 13)
        Me.FlatLabel12.TabIndex = 0
        Me.FlatLabel12.Text = "DNS To IP:"
        '
        'ScanAllPorts
        '
        '
        'SinglePortScan
        '
        '
        'PanelSystemInfo
        '
        Me.PanelSystemInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelSystemInfo.AutoScroll = True
        Me.PanelSystemInfo.Controls.Add(Me.FlatButton18)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel27)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox16)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel26)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox15)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel25)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox14)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel24)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox13)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel23)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox12)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel22)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox11)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel21)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox10)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel20)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox9)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel19)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox8)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel18)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox7)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel17)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox6)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel16)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox20)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel15)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox21)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel1)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox22)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel2)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox23)
        Me.PanelSystemInfo.Controls.Add(Me.FlatLabel3)
        Me.PanelSystemInfo.Controls.Add(Me.FlatTextBox24)
        Me.PanelSystemInfo.Location = New System.Drawing.Point(12, 43)
        Me.PanelSystemInfo.Name = "PanelSystemInfo"
        Me.PanelSystemInfo.Size = New System.Drawing.Size(327, 474)
        Me.PanelSystemInfo.TabIndex = 15
        Me.PanelSystemInfo.Visible = False
        '
        'FlatButton18
        '
        Me.FlatButton18.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton18.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton18.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton18.Location = New System.Drawing.Point(3, 3)
        Me.FlatButton18.Name = "FlatButton18"
        Me.FlatButton18.Rounded = False
        Me.FlatButton18.Size = New System.Drawing.Size(321, 35)
        Me.FlatButton18.TabIndex = 38
        Me.FlatButton18.Text = "Refresh"
        Me.FlatButton18.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatLabel27
        '
        Me.FlatLabel27.AutoSize = True
        Me.FlatLabel27.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel27.ForeColor = System.Drawing.Color.White
        Me.FlatLabel27.Location = New System.Drawing.Point(3, 329)
        Me.FlatLabel27.Name = "FlatLabel27"
        Me.FlatLabel27.Size = New System.Drawing.Size(87, 13)
        Me.FlatLabel27.TabIndex = 31
        Me.FlatLabel27.Text = "Computer Model:"
        '
        'FlatTextBox16
        '
        Me.FlatTextBox16.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox16.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox16.Location = New System.Drawing.Point(3, 777)
        Me.FlatTextBox16.MaxLength = 32767
        Me.FlatTextBox16.Multiline = False
        Me.FlatTextBox16.Name = "FlatTextBox16"
        Me.FlatTextBox16.ReadOnly = False
        Me.FlatTextBox16.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox16.TabIndex = 30
        Me.FlatTextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox16.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox16.UseSystemPasswordChar = False
        '
        'FlatLabel26
        '
        Me.FlatLabel26.AutoSize = True
        Me.FlatLabel26.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel26.ForeColor = System.Drawing.Color.White
        Me.FlatLabel26.Location = New System.Drawing.Point(3, 761)
        Me.FlatLabel26.Name = "FlatLabel26"
        Me.FlatLabel26.Size = New System.Drawing.Size(93, 13)
        Me.FlatLabel26.TabIndex = 29
        Me.FlatLabel26.Text = "Public IP Address:"
        '
        'FlatTextBox15
        '
        Me.FlatTextBox15.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox15.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox15.Location = New System.Drawing.Point(3, 729)
        Me.FlatTextBox15.MaxLength = 32767
        Me.FlatTextBox15.Multiline = False
        Me.FlatTextBox15.Name = "FlatTextBox15"
        Me.FlatTextBox15.ReadOnly = False
        Me.FlatTextBox15.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox15.TabIndex = 28
        Me.FlatTextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox15.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox15.UseSystemPasswordChar = False
        '
        'FlatLabel25
        '
        Me.FlatLabel25.AutoSize = True
        Me.FlatLabel25.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel25.ForeColor = System.Drawing.Color.White
        Me.FlatLabel25.Location = New System.Drawing.Point(3, 713)
        Me.FlatLabel25.Name = "FlatLabel25"
        Me.FlatLabel25.Size = New System.Drawing.Size(74, 13)
        Me.FlatLabel25.TabIndex = 27
        Me.FlatLabel25.Text = "MAC Address:"
        '
        'FlatTextBox14
        '
        Me.FlatTextBox14.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox14.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox14.Location = New System.Drawing.Point(3, 681)
        Me.FlatTextBox14.MaxLength = 32767
        Me.FlatTextBox14.Multiline = False
        Me.FlatTextBox14.Name = "FlatTextBox14"
        Me.FlatTextBox14.ReadOnly = False
        Me.FlatTextBox14.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox14.TabIndex = 26
        Me.FlatTextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox14.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox14.UseSystemPasswordChar = False
        '
        'FlatLabel24
        '
        Me.FlatLabel24.AutoSize = True
        Me.FlatLabel24.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel24.ForeColor = System.Drawing.Color.White
        Me.FlatLabel24.Location = New System.Drawing.Point(3, 665)
        Me.FlatLabel24.Name = "FlatLabel24"
        Me.FlatLabel24.Size = New System.Drawing.Size(90, 13)
        Me.FlatLabel24.TabIndex = 25
        Me.FlatLabel24.Text = "Local IP Address:"
        '
        'FlatTextBox13
        '
        Me.FlatTextBox13.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox13.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox13.Location = New System.Drawing.Point(3, 633)
        Me.FlatTextBox13.MaxLength = 32767
        Me.FlatTextBox13.Multiline = False
        Me.FlatTextBox13.Name = "FlatTextBox13"
        Me.FlatTextBox13.ReadOnly = False
        Me.FlatTextBox13.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox13.TabIndex = 24
        Me.FlatTextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox13.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox13.UseSystemPasswordChar = False
        '
        'FlatLabel23
        '
        Me.FlatLabel23.AutoSize = True
        Me.FlatLabel23.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel23.ForeColor = System.Drawing.Color.White
        Me.FlatLabel23.Location = New System.Drawing.Point(3, 617)
        Me.FlatLabel23.Name = "FlatLabel23"
        Me.FlatLabel23.Size = New System.Drawing.Size(96, 13)
        Me.FlatLabel23.TabIndex = 23
        Me.FlatLabel23.Text = "Network Available:"
        '
        'FlatTextBox12
        '
        Me.FlatTextBox12.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox12.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox12.Location = New System.Drawing.Point(3, 585)
        Me.FlatTextBox12.MaxLength = 32767
        Me.FlatTextBox12.Multiline = False
        Me.FlatTextBox12.Name = "FlatTextBox12"
        Me.FlatTextBox12.ReadOnly = False
        Me.FlatTextBox12.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox12.TabIndex = 22
        Me.FlatTextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox12.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox12.UseSystemPasswordChar = False
        '
        'FlatLabel22
        '
        Me.FlatLabel22.AutoSize = True
        Me.FlatLabel22.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel22.ForeColor = System.Drawing.Color.White
        Me.FlatLabel22.Location = New System.Drawing.Point(3, 569)
        Me.FlatLabel22.Name = "FlatLabel22"
        Me.FlatLabel22.Size = New System.Drawing.Size(92, 13)
        Me.FlatLabel22.TabIndex = 21
        Me.FlatLabel22.Text = "Computer Display:"
        '
        'FlatTextBox11
        '
        Me.FlatTextBox11.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox11.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox11.Location = New System.Drawing.Point(3, 537)
        Me.FlatTextBox11.MaxLength = 32767
        Me.FlatTextBox11.Multiline = False
        Me.FlatTextBox11.Name = "FlatTextBox11"
        Me.FlatTextBox11.ReadOnly = False
        Me.FlatTextBox11.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox11.TabIndex = 20
        Me.FlatTextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox11.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox11.UseSystemPasswordChar = False
        '
        'FlatLabel21
        '
        Me.FlatLabel21.AutoSize = True
        Me.FlatLabel21.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel21.ForeColor = System.Drawing.Color.White
        Me.FlatLabel21.Location = New System.Drawing.Point(3, 521)
        Me.FlatLabel21.Name = "FlatLabel21"
        Me.FlatLabel21.Size = New System.Drawing.Size(47, 13)
        Me.FlatLabel21.TabIndex = 19
        Me.FlatLabel21.Text = "Memory:"
        '
        'FlatTextBox10
        '
        Me.FlatTextBox10.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox10.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox10.Location = New System.Drawing.Point(3, 489)
        Me.FlatTextBox10.MaxLength = 32767
        Me.FlatTextBox10.Multiline = False
        Me.FlatTextBox10.Name = "FlatTextBox10"
        Me.FlatTextBox10.ReadOnly = False
        Me.FlatTextBox10.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox10.TabIndex = 18
        Me.FlatTextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox10.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox10.UseSystemPasswordChar = False
        '
        'FlatLabel20
        '
        Me.FlatLabel20.AutoSize = True
        Me.FlatLabel20.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel20.ForeColor = System.Drawing.Color.White
        Me.FlatLabel20.Location = New System.Drawing.Point(3, 473)
        Me.FlatLabel20.Name = "FlatLabel20"
        Me.FlatLabel20.Size = New System.Drawing.Size(57, 13)
        Me.FlatLabel20.TabIndex = 17
        Me.FlatLabel20.Text = "Processor:"
        '
        'FlatTextBox9
        '
        Me.FlatTextBox9.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox9.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox9.Location = New System.Drawing.Point(3, 441)
        Me.FlatTextBox9.MaxLength = 32767
        Me.FlatTextBox9.Multiline = False
        Me.FlatTextBox9.Name = "FlatTextBox9"
        Me.FlatTextBox9.ReadOnly = False
        Me.FlatTextBox9.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox9.TabIndex = 16
        Me.FlatTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox9.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox9.UseSystemPasswordChar = False
        '
        'FlatLabel19
        '
        Me.FlatLabel19.AutoSize = True
        Me.FlatLabel19.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel19.ForeColor = System.Drawing.Color.White
        Me.FlatLabel19.Location = New System.Drawing.Point(3, 425)
        Me.FlatLabel19.Name = "FlatLabel19"
        Me.FlatLabel19.Size = New System.Drawing.Size(99, 13)
        Me.FlatLabel19.TabIndex = 15
        Me.FlatLabel19.Text = "Windows Directory:"
        '
        'FlatTextBox8
        '
        Me.FlatTextBox8.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox8.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox8.Location = New System.Drawing.Point(3, 393)
        Me.FlatTextBox8.MaxLength = 32767
        Me.FlatTextBox8.Multiline = False
        Me.FlatTextBox8.Name = "FlatTextBox8"
        Me.FlatTextBox8.ReadOnly = False
        Me.FlatTextBox8.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox8.TabIndex = 14
        Me.FlatTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox8.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox8.UseSystemPasswordChar = False
        '
        'FlatLabel18
        '
        Me.FlatLabel18.AutoSize = True
        Me.FlatLabel18.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel18.ForeColor = System.Drawing.Color.White
        Me.FlatLabel18.Location = New System.Drawing.Point(3, 377)
        Me.FlatLabel18.Name = "FlatLabel18"
        Me.FlatLabel18.Size = New System.Drawing.Size(71, 13)
        Me.FlatLabel18.TabIndex = 13
        Me.FlatLabel18.Text = "System Type:"
        '
        'FlatTextBox7
        '
        Me.FlatTextBox7.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox7.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox7.Location = New System.Drawing.Point(3, 345)
        Me.FlatTextBox7.MaxLength = 32767
        Me.FlatTextBox7.Multiline = False
        Me.FlatTextBox7.Name = "FlatTextBox7"
        Me.FlatTextBox7.ReadOnly = False
        Me.FlatTextBox7.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox7.TabIndex = 12
        Me.FlatTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox7.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox7.UseSystemPasswordChar = False
        '
        'FlatLabel17
        '
        Me.FlatLabel17.AutoSize = True
        Me.FlatLabel17.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel17.ForeColor = System.Drawing.Color.White
        Me.FlatLabel17.Location = New System.Drawing.Point(3, 281)
        Me.FlatLabel17.Name = "FlatLabel17"
        Me.FlatLabel17.Size = New System.Drawing.Size(121, 13)
        Me.FlatLabel17.TabIndex = 11
        Me.FlatLabel17.Text = "Computer Manufacturer:"
        '
        'FlatTextBox6
        '
        Me.FlatTextBox6.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox6.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox6.Location = New System.Drawing.Point(3, 297)
        Me.FlatTextBox6.MaxLength = 32767
        Me.FlatTextBox6.Multiline = False
        Me.FlatTextBox6.Name = "FlatTextBox6"
        Me.FlatTextBox6.ReadOnly = False
        Me.FlatTextBox6.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox6.TabIndex = 10
        Me.FlatTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox6.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox6.UseSystemPasswordChar = False
        '
        'FlatLabel16
        '
        Me.FlatLabel16.AutoSize = True
        Me.FlatLabel16.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel16.ForeColor = System.Drawing.Color.White
        Me.FlatLabel16.Location = New System.Drawing.Point(3, 233)
        Me.FlatLabel16.Name = "FlatLabel16"
        Me.FlatLabel16.Size = New System.Drawing.Size(86, 13)
        Me.FlatLabel16.TabIndex = 9
        Me.FlatLabel16.Text = "Computer Name:"
        '
        'FlatTextBox20
        '
        Me.FlatTextBox20.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox20.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox20.Location = New System.Drawing.Point(3, 249)
        Me.FlatTextBox20.MaxLength = 32767
        Me.FlatTextBox20.Multiline = False
        Me.FlatTextBox20.Name = "FlatTextBox20"
        Me.FlatTextBox20.ReadOnly = False
        Me.FlatTextBox20.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox20.TabIndex = 8
        Me.FlatTextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox20.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox20.UseSystemPasswordChar = False
        '
        'FlatLabel15
        '
        Me.FlatLabel15.AutoSize = True
        Me.FlatLabel15.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel15.ForeColor = System.Drawing.Color.White
        Me.FlatLabel15.Location = New System.Drawing.Point(3, 185)
        Me.FlatLabel15.Name = "FlatLabel15"
        Me.FlatLabel15.Size = New System.Drawing.Size(107, 13)
        Me.FlatLabel15.TabIndex = 7
        Me.FlatLabel15.Text = "Windows Bit Version:"
        '
        'FlatTextBox21
        '
        Me.FlatTextBox21.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox21.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox21.Location = New System.Drawing.Point(3, 201)
        Me.FlatTextBox21.MaxLength = 32767
        Me.FlatTextBox21.Multiline = False
        Me.FlatTextBox21.Name = "FlatTextBox21"
        Me.FlatTextBox21.ReadOnly = False
        Me.FlatTextBox21.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox21.TabIndex = 6
        Me.FlatTextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox21.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox21.UseSystemPasswordChar = False
        '
        'FlatLabel1
        '
        Me.FlatLabel1.AutoSize = True
        Me.FlatLabel1.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel1.ForeColor = System.Drawing.Color.White
        Me.FlatLabel1.Location = New System.Drawing.Point(3, 137)
        Me.FlatLabel1.Name = "FlatLabel1"
        Me.FlatLabel1.Size = New System.Drawing.Size(63, 13)
        Me.FlatLabel1.TabIndex = 5
        Me.FlatLabel1.Text = "OS Version:"
        '
        'FlatTextBox22
        '
        Me.FlatTextBox22.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox22.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox22.Location = New System.Drawing.Point(3, 153)
        Me.FlatTextBox22.MaxLength = 32767
        Me.FlatTextBox22.Multiline = False
        Me.FlatTextBox22.Name = "FlatTextBox22"
        Me.FlatTextBox22.ReadOnly = False
        Me.FlatTextBox22.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox22.TabIndex = 4
        Me.FlatTextBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox22.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox22.UseSystemPasswordChar = False
        '
        'FlatLabel2
        '
        Me.FlatLabel2.AutoSize = True
        Me.FlatLabel2.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel2.ForeColor = System.Drawing.Color.White
        Me.FlatLabel2.Location = New System.Drawing.Point(3, 89)
        Me.FlatLabel2.Name = "FlatLabel2"
        Me.FlatLabel2.Size = New System.Drawing.Size(66, 13)
        Me.FlatLabel2.TabIndex = 3
        Me.FlatLabel2.Text = "OS Platform:"
        '
        'FlatTextBox23
        '
        Me.FlatTextBox23.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox23.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox23.Location = New System.Drawing.Point(3, 105)
        Me.FlatTextBox23.MaxLength = 32767
        Me.FlatTextBox23.Multiline = False
        Me.FlatTextBox23.Name = "FlatTextBox23"
        Me.FlatTextBox23.ReadOnly = False
        Me.FlatTextBox23.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox23.TabIndex = 2
        Me.FlatTextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox23.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox23.UseSystemPasswordChar = False
        '
        'FlatLabel3
        '
        Me.FlatLabel3.AutoSize = True
        Me.FlatLabel3.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel3.ForeColor = System.Drawing.Color.White
        Me.FlatLabel3.Location = New System.Drawing.Point(3, 41)
        Me.FlatLabel3.Name = "FlatLabel3"
        Me.FlatLabel3.Size = New System.Drawing.Size(25, 13)
        Me.FlatLabel3.TabIndex = 1
        Me.FlatLabel3.Text = "OS:"
        '
        'FlatTextBox24
        '
        Me.FlatTextBox24.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox24.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox24.Location = New System.Drawing.Point(3, 57)
        Me.FlatTextBox24.MaxLength = 32767
        Me.FlatTextBox24.Multiline = False
        Me.FlatTextBox24.Name = "FlatTextBox24"
        Me.FlatTextBox24.ReadOnly = False
        Me.FlatTextBox24.Size = New System.Drawing.Size(321, 29)
        Me.FlatTextBox24.TabIndex = 0
        Me.FlatTextBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox24.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox24.UseSystemPasswordChar = False
        '
        'PanelVT
        '
        Me.PanelVT.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelVT.AutoScroll = True
        Me.PanelVT.Controls.Add(Me.FlatButton29)
        Me.PanelVT.Controls.Add(Me.FlatButton28)
        Me.PanelVT.Controls.Add(Me.FlatListBox1)
        Me.PanelVT.Controls.Add(Me.FlatButton23)
        Me.PanelVT.Controls.Add(Me.FlatLabel5)
        Me.PanelVT.Controls.Add(Me.FlatTextBox18)
        Me.PanelVT.Controls.Add(Me.FlatLabel4)
        Me.PanelVT.Controls.Add(Me.FlatTextBox17)
        Me.PanelVT.Controls.Add(Me.FlatButton19)
        Me.PanelVT.Location = New System.Drawing.Point(12, 43)
        Me.PanelVT.Name = "PanelVT"
        Me.PanelVT.Size = New System.Drawing.Size(427, 474)
        Me.PanelVT.TabIndex = 16
        Me.PanelVT.Visible = False
        '
        'FlatButton29
        '
        Me.FlatButton29.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton29.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton29.ContextMenuStrip = Me.Menu_VTData
        Me.FlatButton29.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton29.Location = New System.Drawing.Point(217, 102)
        Me.FlatButton29.Name = "FlatButton29"
        Me.FlatButton29.Rounded = False
        Me.FlatButton29.Size = New System.Drawing.Size(207, 32)
        Me.FlatButton29.TabIndex = 16
        Me.FlatButton29.Text = "Data"
        Me.FlatButton29.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Menu_VTData
        '
        Me.Menu_VTData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Menu_VTData.ForeColor = System.Drawing.Color.White
        Me.Menu_VTData.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyToolStripMenuItem, Me.ClearToolStripMenuItem})
        Me.Menu_VTData.Name = "Menu_VTData"
        Me.Menu_VTData.ShowImageMargin = False
        Me.Menu_VTData.Size = New System.Drawing.Size(74, 48)
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(73, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(73, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'FlatButton28
        '
        Me.FlatButton28.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton28.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton28.ContextMenuStrip = Me.Menu_VTScan
        Me.FlatButton28.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton28.Location = New System.Drawing.Point(3, 102)
        Me.FlatButton28.Name = "FlatButton28"
        Me.FlatButton28.Rounded = False
        Me.FlatButton28.Size = New System.Drawing.Size(207, 32)
        Me.FlatButton28.TabIndex = 15
        Me.FlatButton28.Text = "Scan"
        Me.FlatButton28.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Menu_VTScan
        '
        Me.Menu_VTScan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Menu_VTScan.ForeColor = System.Drawing.Color.White
        Me.Menu_VTScan.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewReportToolStripMenuItem, Me.ViewReportToolStripMenuItem1, Me.RescanHashToolStripMenuItem, Me.AllProcessesToolStripMenuItem})
        Me.Menu_VTScan.Name = "Manu_VTScan"
        Me.Menu_VTScan.ShowImageMargin = False
        Me.Menu_VTScan.Size = New System.Drawing.Size(115, 92)
        '
        'ViewReportToolStripMenuItem
        '
        Me.ViewReportToolStripMenuItem.Name = "ViewReportToolStripMenuItem"
        Me.ViewReportToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.ViewReportToolStripMenuItem.Text = "Upload File"
        '
        'ViewReportToolStripMenuItem1
        '
        Me.ViewReportToolStripMenuItem1.Name = "ViewReportToolStripMenuItem1"
        Me.ViewReportToolStripMenuItem1.Size = New System.Drawing.Size(114, 22)
        Me.ViewReportToolStripMenuItem1.Text = "View Report"
        '
        'RescanHashToolStripMenuItem
        '
        Me.RescanHashToolStripMenuItem.Name = "RescanHashToolStripMenuItem"
        Me.RescanHashToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.RescanHashToolStripMenuItem.Text = "Rescan Hash"
        '
        'AllProcessesToolStripMenuItem
        '
        Me.AllProcessesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UploadFilesToolStripMenuItem, Me.ViewReportsToolStripMenuItem})
        Me.AllProcessesToolStripMenuItem.Name = "AllProcessesToolStripMenuItem"
        Me.AllProcessesToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.AllProcessesToolStripMenuItem.Text = "All Processes"
        '
        'UploadFilesToolStripMenuItem
        '
        Me.UploadFilesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.UploadFilesToolStripMenuItem.Name = "UploadFilesToolStripMenuItem"
        Me.UploadFilesToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.UploadFilesToolStripMenuItem.Text = "Upload Files"
        '
        'ViewReportsToolStripMenuItem
        '
        Me.ViewReportsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ViewReportsToolStripMenuItem.Name = "ViewReportsToolStripMenuItem"
        Me.ViewReportsToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.ViewReportsToolStripMenuItem.Text = "View Reports"
        '
        'FlatListBox1
        '
        Me.FlatListBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatListBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatListBox1.items = New String() {""}
        Me.FlatListBox1.Location = New System.Drawing.Point(3, 138)
        Me.FlatListBox1.Name = "FlatListBox1"
        Me.FlatListBox1.SelectedColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatListBox1.Size = New System.Drawing.Size(421, 333)
        Me.FlatListBox1.TabIndex = 9
        Me.FlatListBox1.Text = "FlatListBox1"
        '
        'FlatButton23
        '
        Me.FlatButton23.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatButton23.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton23.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton23.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton23.Location = New System.Drawing.Point(395, 22)
        Me.FlatButton23.Name = "FlatButton23"
        Me.FlatButton23.Rounded = False
        Me.FlatButton23.Size = New System.Drawing.Size(29, 27)
        Me.FlatButton23.TabIndex = 8
        Me.FlatButton23.Text = "?"
        Me.FlatButton23.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatLabel5
        '
        Me.FlatLabel5.AutoSize = True
        Me.FlatLabel5.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel5.ForeColor = System.Drawing.Color.White
        Me.FlatLabel5.Location = New System.Drawing.Point(3, 51)
        Me.FlatLabel5.Name = "FlatLabel5"
        Me.FlatLabel5.Size = New System.Drawing.Size(26, 13)
        Me.FlatLabel5.TabIndex = 4
        Me.FlatLabel5.Text = "File:"
        '
        'FlatTextBox18
        '
        Me.FlatTextBox18.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatTextBox18.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox18.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox18.Location = New System.Drawing.Point(3, 67)
        Me.FlatTextBox18.MaxLength = 32767
        Me.FlatTextBox18.Multiline = False
        Me.FlatTextBox18.Name = "FlatTextBox18"
        Me.FlatTextBox18.ReadOnly = True
        Me.FlatTextBox18.Size = New System.Drawing.Size(386, 29)
        Me.FlatTextBox18.TabIndex = 3
        Me.FlatTextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox18.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox18.UseSystemPasswordChar = False
        '
        'FlatLabel4
        '
        Me.FlatLabel4.AutoSize = True
        Me.FlatLabel4.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel4.ForeColor = System.Drawing.Color.White
        Me.FlatLabel4.Location = New System.Drawing.Point(3, 6)
        Me.FlatLabel4.Name = "FlatLabel4"
        Me.FlatLabel4.Size = New System.Drawing.Size(48, 13)
        Me.FlatLabel4.TabIndex = 2
        Me.FlatLabel4.Text = "API Key:"
        '
        'FlatTextBox17
        '
        Me.FlatTextBox17.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatTextBox17.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox17.CustomBaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatTextBox17.Location = New System.Drawing.Point(3, 22)
        Me.FlatTextBox17.MaxLength = 32767
        Me.FlatTextBox17.Multiline = False
        Me.FlatTextBox17.Name = "FlatTextBox17"
        Me.FlatTextBox17.ReadOnly = False
        Me.FlatTextBox17.Size = New System.Drawing.Size(386, 29)
        Me.FlatTextBox17.TabIndex = 1
        Me.FlatTextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox17.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox17.UseSystemPasswordChar = False
        '
        'FlatButton19
        '
        Me.FlatButton19.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatButton19.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton19.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton19.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton19.Location = New System.Drawing.Point(395, 67)
        Me.FlatButton19.Name = "FlatButton19"
        Me.FlatButton19.Rounded = False
        Me.FlatButton19.Size = New System.Drawing.Size(29, 27)
        Me.FlatButton19.TabIndex = 0
        Me.FlatButton19.Text = "..."
        Me.FlatButton19.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'PanelSettings
        '
        Me.PanelSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelSettings.AutoScroll = True
        Me.PanelSettings.Controls.Add(Me.FlatCheckBox4)
        Me.PanelSettings.Controls.Add(Me.FlatCheckBox3)
        Me.PanelSettings.Controls.Add(Me.FlatLabel28)
        Me.PanelSettings.Controls.Add(Me.FlatLabel29)
        Me.PanelSettings.Controls.Add(Me.FlatLabel7)
        Me.PanelSettings.Controls.Add(Me.FlatLabel8)
        Me.PanelSettings.Controls.Add(Me.FlatLabel9)
        Me.PanelSettings.Controls.Add(Me.FlatLabel10)
        Me.PanelSettings.Controls.Add(Me.FlatLabel11)
        Me.PanelSettings.Controls.Add(Me.FlatLabel30)
        Me.PanelSettings.Controls.Add(Me.FlatLabel31)
        Me.PanelSettings.Controls.Add(Me.FlatLabel32)
        Me.PanelSettings.Controls.Add(Me.PictureBox5)
        Me.PanelSettings.Controls.Add(Me.PictureBox4)
        Me.PanelSettings.Controls.Add(Me.PictureBox3)
        Me.PanelSettings.Controls.Add(Me.PictureBox2)
        Me.PanelSettings.Controls.Add(Me.PictureBox1)
        Me.PanelSettings.Controls.Add(Me.FlatLabel33)
        Me.PanelSettings.Controls.Add(Me.FlatLabel34)
        Me.PanelSettings.Controls.Add(Me.FlatLabel35)
        Me.PanelSettings.Controls.Add(Me.FlatLabel36)
        Me.PanelSettings.Controls.Add(Me.FlatLabel37)
        Me.PanelSettings.Controls.Add(Me.FlatLabel38)
        Me.PanelSettings.Controls.Add(Me.FlatLabel39)
        Me.PanelSettings.Controls.Add(Me.FlatLabel40)
        Me.PanelSettings.Controls.Add(Me.FlatCheckBox2)
        Me.PanelSettings.Controls.Add(Me.FlatButton27)
        Me.PanelSettings.Controls.Add(Me.TTcolour)
        Me.PanelSettings.Controls.Add(Me.TBcolour)
        Me.PanelSettings.Controls.Add(Me.Lcolour)
        Me.PanelSettings.Controls.Add(Me.BTcolour)
        Me.PanelSettings.Controls.Add(Me.Pcolour)
        Me.PanelSettings.Controls.Add(Me.BGcolour)
        Me.PanelSettings.Location = New System.Drawing.Point(12, 43)
        Me.PanelSettings.Name = "PanelSettings"
        Me.PanelSettings.Size = New System.Drawing.Size(427, 474)
        Me.PanelSettings.TabIndex = 17
        Me.PanelSettings.Visible = False
        '
        'FlatCheckBox4
        '
        Me.FlatCheckBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox4.Checked = True
        Me.FlatCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.FlatCheckBox4.Location = New System.Drawing.Point(3, 370)
        Me.FlatCheckBox4.Name = "FlatCheckBox4"
        Me.FlatCheckBox4.Options = Side_Menu.FlatCheckBox._Options.Style1
        Me.FlatCheckBox4.Size = New System.Drawing.Size(162, 22)
        Me.FlatCheckBox4.TabIndex = 38
        Me.FlatCheckBox4.Text = "Check For Updates"
        Me.FlatCheckBox4.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatCheckBox3
        '
        Me.FlatCheckBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox3.Checked = False
        Me.FlatCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.FlatCheckBox3.Location = New System.Drawing.Point(3, 342)
        Me.FlatCheckBox3.Name = "FlatCheckBox3"
        Me.FlatCheckBox3.Options = Side_Menu.FlatCheckBox._Options.Style1
        Me.FlatCheckBox3.Size = New System.Drawing.Size(162, 22)
        Me.FlatCheckBox3.TabIndex = 37
        Me.FlatCheckBox3.Text = "Start With Windows"
        Me.FlatCheckBox3.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatLabel28
        '
        Me.FlatLabel28.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel28.ForeColor = System.Drawing.Color.White
        Me.FlatLabel28.Location = New System.Drawing.Point(218, 403)
        Me.FlatLabel28.Name = "FlatLabel28"
        Me.FlatLabel28.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel28.TabIndex = 36
        Me.FlatLabel28.Text = "CoinDesk"
        Me.FlatLabel28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel29
        '
        Me.FlatLabel29.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel29.ForeColor = System.Drawing.Color.White
        Me.FlatLabel29.Location = New System.Drawing.Point(218, 299)
        Me.FlatLabel29.Name = "FlatLabel29"
        Me.FlatLabel29.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel29.TabIndex = 35
        Me.FlatLabel29.Text = "Bitcoin API"
        Me.FlatLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel7
        '
        Me.FlatLabel7.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel7.ForeColor = System.Drawing.Color.White
        Me.FlatLabel7.Location = New System.Drawing.Point(333, 264)
        Me.FlatLabel7.Name = "FlatLabel7"
        Me.FlatLabel7.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel7.TabIndex = 34
        Me.FlatLabel7.Text = "Fixer.io"
        Me.FlatLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel8
        '
        Me.FlatLabel8.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel8.ForeColor = System.Drawing.Color.White
        Me.FlatLabel8.Location = New System.Drawing.Point(333, 161)
        Me.FlatLabel8.Name = "FlatLabel8"
        Me.FlatLabel8.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel8.TabIndex = 33
        Me.FlatLabel8.Text = "Currency API"
        Me.FlatLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel9
        '
        Me.FlatLabel9.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel9.ForeColor = System.Drawing.Color.White
        Me.FlatLabel9.Location = New System.Drawing.Point(218, 265)
        Me.FlatLabel9.Name = "FlatLabel9"
        Me.FlatLabel9.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel9.TabIndex = 32
        Me.FlatLabel9.Text = "omegatechware"
        Me.FlatLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel10
        '
        Me.FlatLabel10.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel10.ForeColor = System.Drawing.Color.White
        Me.FlatLabel10.Location = New System.Drawing.Point(218, 162)
        Me.FlatLabel10.Name = "FlatLabel10"
        Me.FlatLabel10.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel10.TabIndex = 31
        Me.FlatLabel10.Text = "Virus Total Code"
        Me.FlatLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel11
        '
        Me.FlatLabel11.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel11.ForeColor = System.Drawing.Color.White
        Me.FlatLabel11.Location = New System.Drawing.Point(333, 132)
        Me.FlatLabel11.Name = "FlatLabel11"
        Me.FlatLabel11.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel11.TabIndex = 30
        Me.FlatLabel11.Text = "_UnderDog"
        Me.FlatLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel30
        '
        Me.FlatLabel30.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel30.ForeColor = System.Drawing.Color.White
        Me.FlatLabel30.Location = New System.Drawing.Point(333, 29)
        Me.FlatLabel30.Name = "FlatLabel30"
        Me.FlatLabel30.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel30.TabIndex = 29
        Me.FlatLabel30.Text = "Code"
        Me.FlatLabel30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel31
        '
        Me.FlatLabel31.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel31.ForeColor = System.Drawing.Color.White
        Me.FlatLabel31.Location = New System.Drawing.Point(218, 132)
        Me.FlatLabel31.Name = "FlatLabel31"
        Me.FlatLabel31.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel31.TabIndex = 28
        Me.FlatLabel31.Text = "iSynthesis"
        Me.FlatLabel31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlatLabel32
        '
        Me.FlatLabel32.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel32.ForeColor = System.Drawing.Color.White
        Me.FlatLabel32.Location = New System.Drawing.Point(218, 29)
        Me.FlatLabel32.Name = "FlatLabel32"
        Me.FlatLabel32.Size = New System.Drawing.Size(91, 13)
        Me.FlatLabel32.TabIndex = 27
        Me.FlatLabel32.Text = "Theme"
        Me.FlatLabel32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = Global.Side_Menu.My.Resources.Resources.coindesk
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox5.InitialImage = Nothing
        Me.PictureBox5.Location = New System.Drawing.Point(218, 315)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(91, 84)
        Me.PictureBox5.TabIndex = 26
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = Global.Side_Menu.My.Resources.Resources.fixer_io
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox4.InitialImage = Nothing
        Me.PictureBox4.Location = New System.Drawing.Point(333, 177)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(91, 84)
        Me.PictureBox4.TabIndex = 25
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = Global.Side_Menu.My.Resources.Resources.omegatechware
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox3.InitialImage = Nothing
        Me.PictureBox3.Location = New System.Drawing.Point(218, 177)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(91, 84)
        Me.PictureBox3.TabIndex = 24
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = Global.Side_Menu.My.Resources.Resources._Underdog
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.InitialImage = Nothing
        Me.PictureBox2.Location = New System.Drawing.Point(333, 45)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(91, 84)
        Me.PictureBox2.TabIndex = 23
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.Side_Menu.My.Resources.Resources.iSynthesis
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.InitialImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(218, 45)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(91, 84)
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'FlatLabel33
        '
        Me.FlatLabel33.AutoSize = True
        Me.FlatLabel33.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel33.ForeColor = System.Drawing.Color.White
        Me.FlatLabel33.Location = New System.Drawing.Point(4, 264)
        Me.FlatLabel33.Name = "FlatLabel33"
        Me.FlatLabel33.Size = New System.Drawing.Size(102, 13)
        Me.FlatLabel33.TabIndex = 21
        Me.FlatLabel33.Text = "Textbox Text Colour"
        '
        'FlatLabel34
        '
        Me.FlatLabel34.AutoSize = True
        Me.FlatLabel34.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel34.ForeColor = System.Drawing.Color.White
        Me.FlatLabel34.Location = New System.Drawing.Point(4, 217)
        Me.FlatLabel34.Name = "FlatLabel34"
        Me.FlatLabel34.Size = New System.Drawing.Size(114, 13)
        Me.FlatLabel34.TabIndex = 20
        Me.FlatLabel34.Text = "Text/Checkbox Colour"
        '
        'FlatLabel35
        '
        Me.FlatLabel35.AutoSize = True
        Me.FlatLabel35.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel35.ForeColor = System.Drawing.Color.White
        Me.FlatLabel35.Location = New System.Drawing.Point(4, 170)
        Me.FlatLabel35.Name = "FlatLabel35"
        Me.FlatLabel35.Size = New System.Drawing.Size(66, 13)
        Me.FlatLabel35.TabIndex = 19
        Me.FlatLabel35.Text = "Label Colour"
        '
        'FlatLabel36
        '
        Me.FlatLabel36.AutoSize = True
        Me.FlatLabel36.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel36.ForeColor = System.Drawing.Color.White
        Me.FlatLabel36.Location = New System.Drawing.Point(4, 123)
        Me.FlatLabel36.Name = "FlatLabel36"
        Me.FlatLabel36.Size = New System.Drawing.Size(95, 13)
        Me.FlatLabel36.TabIndex = 18
        Me.FlatLabel36.Text = "Button Text Colour"
        '
        'FlatLabel37
        '
        Me.FlatLabel37.AutoSize = True
        Me.FlatLabel37.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel37.ForeColor = System.Drawing.Color.White
        Me.FlatLabel37.Location = New System.Drawing.Point(4, 76)
        Me.FlatLabel37.Name = "FlatLabel37"
        Me.FlatLabel37.Size = New System.Drawing.Size(141, 13)
        Me.FlatLabel37.TabIndex = 17
        Me.FlatLabel37.Text = "Primary Colour (Buttons, Etc)"
        '
        'FlatLabel38
        '
        Me.FlatLabel38.AutoSize = True
        Me.FlatLabel38.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.FlatLabel38.ForeColor = System.Drawing.Color.White
        Me.FlatLabel38.Location = New System.Drawing.Point(4, 29)
        Me.FlatLabel38.Name = "FlatLabel38"
        Me.FlatLabel38.Size = New System.Drawing.Size(98, 13)
        Me.FlatLabel38.TabIndex = 16
        Me.FlatLabel38.Text = "Background Colour"
        '
        'FlatLabel39
        '
        Me.FlatLabel39.AutoSize = True
        Me.FlatLabel39.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.FlatLabel39.ForeColor = System.Drawing.Color.White
        Me.FlatLabel39.Location = New System.Drawing.Point(3, 4)
        Me.FlatLabel39.Name = "FlatLabel39"
        Me.FlatLabel39.Size = New System.Drawing.Size(57, 17)
        Me.FlatLabel39.TabIndex = 15
        Me.FlatLabel39.Text = "Options"
        '
        'FlatLabel40
        '
        Me.FlatLabel40.AutoSize = True
        Me.FlatLabel40.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.FlatLabel40.ForeColor = System.Drawing.Color.White
        Me.FlatLabel40.Location = New System.Drawing.Point(214, 4)
        Me.FlatLabel40.Name = "FlatLabel40"
        Me.FlatLabel40.Size = New System.Drawing.Size(52, 17)
        Me.FlatLabel40.TabIndex = 14
        Me.FlatLabel40.Text = "Credits"
        '
        'FlatCheckBox2
        '
        Me.FlatCheckBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox2.Checked = False
        Me.FlatCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.FlatCheckBox2.Location = New System.Drawing.Point(3, 314)
        Me.FlatCheckBox2.Name = "FlatCheckBox2"
        Me.FlatCheckBox2.Options = Side_Menu.FlatCheckBox._Options.Style1
        Me.FlatCheckBox2.Size = New System.Drawing.Size(162, 22)
        Me.FlatCheckBox2.TabIndex = 13
        Me.FlatCheckBox2.Text = "Rounded Buttons"
        Me.FlatCheckBox2.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton27
        '
        Me.FlatButton27.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton27.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton27.Cursor = System.Windows.Forms.Cursors.Default
        Me.FlatButton27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.FlatButton27.Location = New System.Drawing.Point(3, 398)
        Me.FlatButton27.Name = "FlatButton27"
        Me.FlatButton27.Rounded = False
        Me.FlatButton27.Size = New System.Drawing.Size(162, 32)
        Me.FlatButton27.TabIndex = 12
        Me.FlatButton27.Text = "Refresh"
        Me.FlatButton27.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'TTcolour
        '
        Me.TTcolour.BackColor = System.Drawing.Color.Transparent
        Me.TTcolour.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.TTcolour.Cursor = System.Windows.Forms.Cursors.Default
        Me.TTcolour.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TTcolour.Location = New System.Drawing.Point(3, 280)
        Me.TTcolour.Name = "TTcolour"
        Me.TTcolour.Rounded = False
        Me.TTcolour.Size = New System.Drawing.Size(162, 28)
        Me.TTcolour.TabIndex = 11
        Me.TTcolour.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'TBcolour
        '
        Me.TBcolour.BackColor = System.Drawing.Color.Transparent
        Me.TBcolour.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.TBcolour.Cursor = System.Windows.Forms.Cursors.Default
        Me.TBcolour.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TBcolour.Location = New System.Drawing.Point(3, 233)
        Me.TBcolour.Name = "TBcolour"
        Me.TBcolour.Rounded = False
        Me.TBcolour.Size = New System.Drawing.Size(162, 28)
        Me.TBcolour.TabIndex = 9
        Me.TBcolour.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Lcolour
        '
        Me.Lcolour.BackColor = System.Drawing.Color.Transparent
        Me.Lcolour.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.Lcolour.Cursor = System.Windows.Forms.Cursors.Default
        Me.Lcolour.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Lcolour.Location = New System.Drawing.Point(3, 186)
        Me.Lcolour.Name = "Lcolour"
        Me.Lcolour.Rounded = False
        Me.Lcolour.Size = New System.Drawing.Size(162, 28)
        Me.Lcolour.TabIndex = 7
        Me.Lcolour.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'BTcolour
        '
        Me.BTcolour.BackColor = System.Drawing.Color.Transparent
        Me.BTcolour.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.BTcolour.Cursor = System.Windows.Forms.Cursors.Default
        Me.BTcolour.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.BTcolour.Location = New System.Drawing.Point(3, 139)
        Me.BTcolour.Name = "BTcolour"
        Me.BTcolour.Rounded = False
        Me.BTcolour.Size = New System.Drawing.Size(162, 28)
        Me.BTcolour.TabIndex = 5
        Me.BTcolour.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Pcolour
        '
        Me.Pcolour.BackColor = System.Drawing.Color.Transparent
        Me.Pcolour.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.Pcolour.Cursor = System.Windows.Forms.Cursors.Default
        Me.Pcolour.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Pcolour.Location = New System.Drawing.Point(3, 92)
        Me.Pcolour.Name = "Pcolour"
        Me.Pcolour.Rounded = False
        Me.Pcolour.Size = New System.Drawing.Size(162, 28)
        Me.Pcolour.TabIndex = 3
        Me.Pcolour.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'BGcolour
        '
        Me.BGcolour.BackColor = System.Drawing.Color.Transparent
        Me.BGcolour.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.BGcolour.Cursor = System.Windows.Forms.Cursors.Default
        Me.BGcolour.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.BGcolour.Location = New System.Drawing.Point(3, 45)
        Me.BGcolour.Name = "BGcolour"
        Me.BGcolour.Rounded = False
        Me.BGcolour.Size = New System.Drawing.Size(162, 28)
        Me.BGcolour.TabIndex = 1
        Me.BGcolour.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'StayActive
        '
        Me.StayActive.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.StayActive.BackColor = System.Drawing.Color.Gray
        Me.StayActive.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.StayActive.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.StayActive.Checked = False
        Me.StayActive.Cursor = System.Windows.Forms.Cursors.Hand
        Me.StayActive.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.StayActive.Location = New System.Drawing.Point(12, 548)
        Me.StayActive.Name = "StayActive"
        Me.StayActive.Options = Side_Menu.FlatCheckBox._Options.Style1
        Me.StayActive.Size = New System.Drawing.Size(94, 22)
        Me.StayActive.TabIndex = 3
        Me.StayActive.Text = "Stay Active"
        Me.StayActive.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Time
        '
        Me.Time.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Time.BackColor = System.Drawing.Color.Transparent
        Me.Time.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Time.ForeColor = System.Drawing.Color.White
        Me.Time.Location = New System.Drawing.Point(0, 0)
        Me.Time.Name = "Time"
        Me.Time.Size = New System.Drawing.Size(536, 40)
        Me.Time.TabIndex = 2
        Me.Time.Text = "Time"
        Me.Time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.ContextMenuStrip = Me.Menu_Icon
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "Side Menu"
        Me.NotifyIcon1.Visible = True
        '
        'Menu_Icon
        '
        Me.Menu_Icon.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Menu_Icon.ForeColor = System.Drawing.Color.White
        Me.Menu_Icon.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.Menu_Icon.Name = "FlatContextMenuStrip1"
        Me.Menu_Icon.ShowImageMargin = False
        Me.Menu_Icon.Size = New System.Drawing.Size(76, 48)
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(75, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(75, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gray
        Me.ClientSize = New System.Drawing.Size(536, 578)
        Me.ControlBox = False
        Me.Controls.Add(Me.StayActive)
        Me.Controls.Add(Me.Time)
        Me.Controls.Add(Me.PanelWidget)
        Me.Controls.Add(Me.PanelCMD)
        Me.Controls.Add(Me.PanelMemo)
        Me.Controls.Add(Me.PanelNetworkTools)
        Me.Controls.Add(Me.PanelSystemInfo)
        Me.Controls.Add(Me.PanelVT)
        Me.Controls.Add(Me.PanelSettings)
        Me.Controls.Add(Me.PanelMain)
        Me.DoubleBuffered = True
        Me.ForeColor = System.Drawing.Color.Black
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Main"
        Me.Opacity = 0.9R
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main"
        Me.TopMost = True
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.PanelMain.ResumeLayout(False)
        Me.PanelCMD.ResumeLayout(False)
        Me.PanelWidget.ResumeLayout(False)
        Me.PanelMemo.ResumeLayout(False)
        Me.PanelNetworkTools.ResumeLayout(False)
        Me.PanelNetworkTools.PerformLayout()
        Me.PanelSystemInfo.ResumeLayout(False)
        Me.PanelSystemInfo.PerformLayout()
        Me.PanelVT.ResumeLayout(False)
        Me.PanelVT.PerformLayout()
        Me.Menu_VTData.ResumeLayout(False)
        Me.Menu_VTScan.ResumeLayout(False)
        Me.PanelSettings.ResumeLayout(False)
        Me.PanelSettings.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Menu_Icon.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelMain As Panel
    Friend WithEvents UpdateTime As Timer
    Friend WithEvents StayActive As FlatCheckBox
    Friend WithEvents FlatButton6 As FlatButton
    Friend WithEvents FlatButton5 As FlatButton
    Friend WithEvents FlatButton4 As FlatButton
    Friend WithEvents FlatButton3 As FlatButton
    Friend WithEvents FlatButton2 As FlatButton
    Friend WithEvents FlatButton1 As FlatButton
    Friend WithEvents PanelWidget As Panel
    Friend WithEvents FlatButton7 As FlatButton
    Friend WithEvents FlatButton8 As FlatButton
    Friend WithEvents FlatButton11 As FlatButton
    Friend WithEvents PanelCMD As Panel
    Friend WithEvents FlatTextBox1 As FlatTextBox
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents FlatButton10 As FlatButton
    Friend WithEvents FlatButton9 As FlatButton
    Friend WithEvents FlatButton12 As FlatButton
    Friend WithEvents PanelMemo As Panel
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents PanelNetworkTools As Panel
    Friend WithEvents FlatLabel14 As FlatLabel
    Friend WithEvents FlatCheckBox1 As FlatCheckBox
    Friend WithEvents FlatButton13 As FlatButton
    Friend WithEvents FlatButton14 As FlatButton
    Friend WithEvents FlatButton15 As FlatButton
    Friend WithEvents FlatButton16 As FlatButton
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents FlatTextBox4 As FlatTextBox
    Friend WithEvents FlatTextBox3 As FlatTextBox
    Friend WithEvents FlatLabel13 As FlatLabel
    Friend WithEvents FlatButton17 As FlatButton
    Friend WithEvents FlatTextBox2 As FlatTextBox
    Friend WithEvents FlatTextBox5 As FlatTextBox
    Friend WithEvents FlatLabel12 As FlatLabel
    Friend WithEvents ScanAllPorts As System.ComponentModel.BackgroundWorker
    Friend WithEvents SinglePortScan As System.ComponentModel.BackgroundWorker
    Friend WithEvents PanelSystemInfo As Panel
    Friend WithEvents FlatButton18 As FlatButton
    Friend WithEvents FlatLabel27 As FlatLabel
    Friend WithEvents FlatTextBox16 As FlatTextBox
    Friend WithEvents FlatLabel26 As FlatLabel
    Friend WithEvents FlatTextBox15 As FlatTextBox
    Friend WithEvents FlatLabel25 As FlatLabel
    Friend WithEvents FlatTextBox14 As FlatTextBox
    Friend WithEvents FlatLabel24 As FlatLabel
    Friend WithEvents FlatTextBox13 As FlatTextBox
    Friend WithEvents FlatLabel23 As FlatLabel
    Friend WithEvents FlatTextBox12 As FlatTextBox
    Friend WithEvents FlatLabel22 As FlatLabel
    Friend WithEvents FlatTextBox11 As FlatTextBox
    Friend WithEvents FlatLabel21 As FlatLabel
    Friend WithEvents FlatTextBox10 As FlatTextBox
    Friend WithEvents FlatLabel20 As FlatLabel
    Friend WithEvents FlatTextBox9 As FlatTextBox
    Friend WithEvents FlatLabel19 As FlatLabel
    Friend WithEvents FlatTextBox8 As FlatTextBox
    Friend WithEvents FlatLabel18 As FlatLabel
    Friend WithEvents FlatTextBox7 As FlatTextBox
    Friend WithEvents FlatLabel17 As FlatLabel
    Friend WithEvents FlatTextBox6 As FlatTextBox
    Friend WithEvents FlatLabel16 As FlatLabel
    Friend WithEvents FlatTextBox20 As FlatTextBox
    Friend WithEvents FlatLabel15 As FlatLabel
    Friend WithEvents FlatTextBox21 As FlatTextBox
    Friend WithEvents FlatLabel1 As FlatLabel
    Friend WithEvents FlatTextBox22 As FlatTextBox
    Friend WithEvents FlatLabel2 As FlatLabel
    Friend WithEvents FlatTextBox23 As FlatTextBox
    Friend WithEvents FlatLabel3 As FlatLabel
    Friend WithEvents FlatTextBox24 As FlatTextBox
    Friend WithEvents PanelVT As Panel
    Friend WithEvents FlatTextBox17 As FlatTextBox
    Friend WithEvents FlatButton19 As FlatButton
    Friend WithEvents FlatLabel5 As FlatLabel
    Friend WithEvents FlatTextBox18 As FlatTextBox
    Friend WithEvents FlatLabel4 As FlatLabel
    Friend WithEvents FlatButton23 As FlatButton
    Friend WithEvents VT_FileSelect As OpenFileDialog
    Friend WithEvents FlatListBox1 As FlatListBox
    Friend WithEvents Time As FlatLabel
    Friend WithEvents NotifyIcon1 As NotifyIcon
    Friend WithEvents Menu_Icon As FlatContextMenuStrip
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PanelSettings As Panel
    Friend WithEvents FlatLabel28 As FlatLabel
    Friend WithEvents FlatLabel29 As FlatLabel
    Friend WithEvents FlatLabel7 As FlatLabel
    Friend WithEvents FlatLabel8 As FlatLabel
    Friend WithEvents FlatLabel9 As FlatLabel
    Friend WithEvents FlatLabel10 As FlatLabel
    Friend WithEvents FlatLabel11 As FlatLabel
    Friend WithEvents FlatLabel30 As FlatLabel
    Friend WithEvents FlatLabel31 As FlatLabel
    Friend WithEvents FlatLabel32 As FlatLabel
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents FlatLabel33 As FlatLabel
    Friend WithEvents FlatLabel34 As FlatLabel
    Friend WithEvents FlatLabel35 As FlatLabel
    Friend WithEvents FlatLabel36 As FlatLabel
    Friend WithEvents FlatLabel37 As FlatLabel
    Friend WithEvents FlatLabel38 As FlatLabel
    Friend WithEvents FlatLabel39 As FlatLabel
    Friend WithEvents FlatLabel40 As FlatLabel
    Friend WithEvents FlatCheckBox2 As FlatCheckBox
    Friend WithEvents FlatButton27 As FlatButton
    Friend WithEvents TTcolour As FlatButton
    Friend WithEvents TBcolour As FlatButton
    Friend WithEvents Lcolour As FlatButton
    Friend WithEvents BTcolour As FlatButton
    Friend WithEvents Pcolour As FlatButton
    Friend WithEvents BGcolour As FlatButton
    Friend WithEvents FlatCheckBox4 As FlatCheckBox
    Friend WithEvents FlatCheckBox3 As FlatCheckBox
    Friend WithEvents FlatButton29 As FlatButton
    Friend WithEvents FlatButton28 As FlatButton
    Friend WithEvents Menu_VTScan As FlatContextMenuStrip
    Friend WithEvents ViewReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Menu_VTData As FlatContextMenuStrip
    Friend WithEvents ViewReportToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RescanHashToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AllProcessesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UploadFilesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewReportsToolStripMenuItem As ToolStripMenuItem
End Class
