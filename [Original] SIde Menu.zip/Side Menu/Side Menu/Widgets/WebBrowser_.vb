﻿Public Class WebBrowser_
    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        WebBrowser1.Navigate(FlatTextBox1.Text)
    End Sub

    Private Sub WebBrowser1_Navigated(sender As Object, e As WebBrowserNavigatedEventArgs) Handles WebBrowser1.Navigated
        FlatTextBox1.Text = WebBrowser1.Url.ToString
    End Sub

    Dim FResize
    Private Sub FlatButton4_MouseDown(sender As Object, e As MouseEventArgs) Handles FlatButton4.MouseDown
        FResize = True
    End Sub

    Private Sub FlatButton4_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton4.MouseMove
        If FResize = True Then
            Me.Width = Windows.Forms.Cursor.Position.X - Me.Location.X
            Me.Height = Windows.Forms.Cursor.Position.Y - Me.Location.Y
        End If
    End Sub

    Private Sub FlatButton4_MouseUp(sender As Object, e As MouseEventArgs) Handles FlatButton4.MouseUp
        FResize = False
        WebBrowser1.ScriptErrorsSuppressed = True
    End Sub

    Private Sub FlatCheckBox1_CheckedChanged(sender As Object) Handles FlatCheckBox1.CheckedChanged
        Me.TopMost = FlatCheckBox1.Checked
    End Sub

    Private Sub FlatClose1_Click(sender As Object, e As EventArgs) Handles FlatClose1.Click
        Me.Close()
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        WebBrowser1.GoBack()
    End Sub

    Private Sub FlatButton3_Click(sender As Object, e As EventArgs) Handles FlatButton3.Click
        WebBrowser1.Refresh()
    End Sub
End Class