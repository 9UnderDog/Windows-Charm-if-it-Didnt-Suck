﻿Imports System.IO
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq

Public Class Currency
    Private Sub FlatCheckBox1_CheckedChanged(sender As Object) Handles FlatCheckBox1.CheckedChanged
        If FlatCheckBox1.Checked = True Then
            UpdateList.Start()
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf GetCurrency)
            thread.Start()
        Else
            UpdateList.Stop()
        End If
        My.Settings.CurrencyRefresh = FlatCheckBox1.Checked
        My.Settings.Save()
    End Sub

    Dim FirstLoad As Boolean = False
    Private Sub Currency_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        CheckForIllegalCrossThreadCalls = False
        UpdateList.Stop()
        FlatComboBox1.SelectedItem = My.Settings.DefualtCurrency
        FlatComboBox2.SelectedItem = My.Settings.SecondaryCurrency
        FlatCheckBox1.Checked = My.Settings.CurrencyRefresh
        Dim thread As System.Threading.Thread
        thread = New System.Threading.Thread(AddressOf GetCurrency)
        thread.Start()
    End Sub

    Private Sub UpdateList_Tick(sender As Object, e As EventArgs) Handles UpdateList.Tick
        FlatListBox1.Clear()
        Dim thread As System.Threading.Thread
        thread = New System.Threading.Thread(AddressOf GetCurrency)
        thread.Start()
    End Sub

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        FlatListBox1.Clear()
        Dim thread As System.Threading.Thread
        thread = New System.Threading.Thread(AddressOf GetCurrency)
        thread.Start()
    End Sub

    Private Sub GetCurrency()
        Dim ss As String = New System.Net.WebClient().DownloadString("http://api.fixer.io/latest?base=" & FlatComboBox1.SelectedItem)
        On Error Resume Next
        Dim AUD As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "AUD" & Chr(34) & ":", ",")
        If AUD = 0 Then
            AUD = 1
        End If
        Dim BGN As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "BGN" & Chr(34) & ":", ",")
        If BGN = 0 Then
            BGN = 1
        End If
        Dim BRL As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "BRL" & Chr(34) & ":", ",")
        If BRL = 0 Then
            BRL = 1
        End If
        Dim CAD As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "CAD" & Chr(34) & ":", ",")
        If CAD = 0 Then
            CAD = 1
        End If
        Dim CHF As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "CHF" & Chr(34) & ":", ",")
        If CHF = 0 Then
            CHF = 1
        End If
        Dim CNY As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "CNY" & Chr(34) & ":", ",")
        If CNY = 0 Then
            CNY = 1
        End If
        Dim CZK As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "CZK" & Chr(34) & ":", ",")
        If CZK = 0 Then
            CZK = 1
        End If
        Dim DKK As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "DKK" & Chr(34) & ":", ",")
        If DKK = 0 Then
            DKK = 1
        End If
        Dim GBP As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "GBP" & Chr(34) & ":", ",")
        If GBP = 0 Then
            GBP = 1
        End If
        Dim HKD As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "HKD" & Chr(34) & ":", ",")
        If HKD = 0 Then
            HKD = 1
        End If
        Dim HRK As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "HRK" & Chr(34) & ":", ",")
        If HRK = 0 Then
            HRK = 1
        End If
        Dim HUF As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "HUF" & Chr(34) & ":", ",")
        If HUF = 0 Then
            HUF = 1
        End If
        Dim IDR As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "IDR" & Chr(34) & ":", ",")
        If IDR = 0 Then
            IDR = 1
        End If
        Dim ILS As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "ILS" & Chr(34) & ":", ",")
        If ILS = 0 Then
            ILS = 1
        End If
        Dim INR As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "INR" & Chr(34) & ":", ",")
        If INR = 0 Then
            INR = 1
        End If
        Dim JPY As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "JPY" & Chr(34) & ":", ",")
        If JPY = 0 Then
            JPY = 1
        End If
        Dim KRW As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "KRW" & Chr(34) & ":", ",")
        If KRW = 0 Then
            KRW = 1
        End If
        Dim MXN As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "MXN" & Chr(34) & ":", ",")
        If MXN = 0 Then
            MXN = 1
        End If
        Dim MYR As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "MYR" & Chr(34) & ":", ",")
        If MYR = 0 Then
            MYR = 1
        End If
        Dim NOK As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "NOK" & Chr(34) & ":", ",")
        If NOK = 0 Then
            NOK = 1
        End If
        Dim NZD As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "NZD" & Chr(34) & ":", ",")
        If NZD = 0 Then
            NZD = 1
        End If
        Dim PHP As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "PHP" & Chr(34) & ":", ",")
        If PHP = 0 Then
            PHP = 1
        End If
        Dim PLN As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "PLN" & Chr(34) & ":", ",")
        If PLN = 0 Then
            PLN = 1
        End If
        Dim RON As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "RON" & Chr(34) & ":", ",")
        If RON = 0 Then
            RON = 1
        End If
        Dim RUB As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "RUB" & Chr(34) & ":", ",")
        If RUB = 0 Then
            RUB = 1
        End If
        Dim SEK As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "SEK" & Chr(34) & ":", ",")
        If SEK = 0 Then
            SEK = 1
        End If
        Dim SGD As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "SGD" & Chr(34) & ":", ",")
        If SGD = 0 Then
            SGD = 1
        End If
        Dim THB As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "THB" & Chr(34) & ":", ",")
        If THB = 0 Then
            THB = 1
        End If
        Dim TRY_ As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "TRY" & Chr(34) & ":", ",")
        If TRY_ = 0 Then
            TRY_ = 1
        End If
        Dim USD As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "USD" & Chr(34) & ":", ",")
        If USD = 0 Then
            USD = 1
        End If
        Dim ZAR As Decimal = SharedCode.getdatainbetween(ss, Chr(34) & "ZAR" & Chr(34) & ":", ",")
        If ZAR = 0 Then
            ZAR = 1
        End If

        Dim bb As String = New System.Net.WebClient().DownloadString("http://api.coindesk.com/v1/bpi/currentprice.json")
        Dim BTC As Decimal = SharedCode.getdatainbetween(bb, Chr(34) & "rate" & Chr(34) & ":" & Chr(34), Chr(34) & ",")
        Dim CR As String = FlatComboBox1.SelectedItem
        Dim CCRBTC
        If CR = "USD" Then
            CCRBTC = BTC
        Else
            Dim bbusd As String = New System.Net.WebClient().DownloadString("http://api.fixer.io/latest?base=USD")
            CCRBTC = BTC * ((SharedCode.getdatainbetween(bbusd, Chr(34) & "AUD" & Chr(34) & ":", ",")))
        End If



        ExportList = ""
        FlatListBox1.AddItem("Base Currency" & vbTab & ":" & vbTab & FlatComboBox1.SelectedItem)
        ExportList &= vbNewLine & "Base Currency" & vbTab & ":" & vbTab & FlatComboBox1.SelectedItem
        FlatListBox1.AddItem("AUD" & vbTab & vbTab & ":" & vbTab & AUD)
        ExportList &= vbNewLine & "AUD" & vbTab & vbTab & ":" & vbTab & AUD
        FlatListBox1.AddItem("BGN" & vbTab & vbTab & ":" & vbTab & BGN)
        ExportList &= vbNewLine & "BGN" & vbTab & vbTab & ":" & vbTab & BGN
        FlatListBox1.AddItem("BRL" & vbTab & vbTab & ":" & vbTab & BRL)
        ExportList &= vbNewLine & "BRL" & vbTab & vbTab & ":" & vbTab & BRL
        FlatListBox1.AddItem("CAD" & vbTab & vbTab & ":" & vbTab & CAD)
        ExportList &= vbNewLine & "CAD" & vbTab & vbTab & ":" & vbTab & CAD
        FlatListBox1.AddItem("CHF" & vbTab & vbTab & ":" & vbTab & CHF)
        ExportList &= vbNewLine & "CHF" & vbTab & vbTab & ":" & vbTab & CHF
        FlatListBox1.AddItem("CNY" & vbTab & vbTab & ":" & vbTab & CNY)
        ExportList &= vbNewLine & "CNY" & vbTab & vbTab & ":" & vbTab & CNY
        FlatListBox1.AddItem("CZK" & vbTab & vbTab & ":" & vbTab & CZK)
        ExportList &= vbNewLine & "CZK" & vbTab & vbTab & ":" & vbTab & CZK
        FlatListBox1.AddItem("DKK" & vbTab & vbTab & ":" & vbTab & DKK)
        ExportList &= vbNewLine & "DKK" & vbTab & vbTab & ":" & vbTab & DKK
        FlatListBox1.AddItem("HKD" & vbTab & vbTab & ":" & vbTab & HKD)
        ExportList &= vbNewLine & "HKD" & vbTab & vbTab & ":" & vbTab & HKD
        FlatListBox1.AddItem("HRK" & vbTab & vbTab & ":" & vbTab & HRK)
        ExportList &= vbNewLine & "HRK" & vbTab & vbTab & ":" & vbTab & HRK
        FlatListBox1.AddItem("HUF" & vbTab & vbTab & ":" & vbTab & HUF)
        ExportList &= vbNewLine & "HUF" & vbTab & vbTab & ":" & vbTab & HUF
        FlatListBox1.AddItem("IDR" & vbTab & vbTab & ":" & vbTab & IDR)
        ExportList &= vbNewLine & "IDR" & vbTab & vbTab & ":" & vbTab & IDR
        FlatListBox1.AddItem("ILS" & vbTab & vbTab & ":" & vbTab & ILS)
        ExportList &= vbNewLine & "ILS" & vbTab & vbTab & ":" & vbTab & ILS
        FlatListBox1.AddItem("INR" & vbTab & vbTab & ":" & vbTab & INR)
        ExportList &= vbNewLine & "INR" & vbTab & vbTab & ":" & vbTab & INR
        FlatListBox1.AddItem("JPY" & vbTab & vbTab & ":" & vbTab & JPY)
        ExportList &= vbNewLine & "JPY" & vbTab & vbTab & ":" & vbTab & JPY
        FlatListBox1.AddItem("KRW" & vbTab & vbTab & ":" & vbTab & KRW)
        ExportList &= vbNewLine & "KRW" & vbTab & vbTab & ":" & vbTab & KRW
        FlatListBox1.AddItem("MXN" & vbTab & vbTab & ":" & vbTab & MXN)
        ExportList &= vbNewLine & "MXN" & vbTab & vbTab & ":" & vbTab & MXN
        FlatListBox1.AddItem("MYR" & vbTab & vbTab & ":" & vbTab & MYR)
        ExportList &= vbNewLine & "MYR" & vbTab & vbTab & ":" & vbTab & MYR
        FlatListBox1.AddItem("NOK" & vbTab & vbTab & ":" & vbTab & NOK)
        ExportList &= vbNewLine & "NOK" & vbTab & vbTab & ":" & vbTab & NOK
        FlatListBox1.AddItem("NZD" & vbTab & vbTab & ":" & vbTab & NZD)
        ExportList &= vbNewLine & "NZD" & vbTab & vbTab & ":" & vbTab & NZD
        FlatListBox1.AddItem("PHP" & vbTab & vbTab & ":" & vbTab & PHP)
        ExportList &= vbNewLine & "PHP" & vbTab & vbTab & ":" & vbTab & PHP
        FlatListBox1.AddItem("PLN" & vbTab & vbTab & ":" & vbTab & PLN)
        ExportList &= vbNewLine & "PLN" & vbTab & vbTab & ":" & vbTab & PLN
        FlatListBox1.AddItem("RON" & vbTab & vbTab & ":" & vbTab & RON)
        ExportList &= vbNewLine & "RON" & vbTab & vbTab & ":" & vbTab & RON
        FlatListBox1.AddItem("RUB" & vbTab & vbTab & ":" & vbTab & RUB)
        ExportList &= vbNewLine & "RUB" & vbTab & vbTab & ":" & vbTab & RUB
        FlatListBox1.AddItem("SEK" & vbTab & vbTab & ":" & vbTab & SEK)
        ExportList &= vbNewLine & "SEK" & vbTab & vbTab & ":" & vbTab & SEK
        FlatListBox1.AddItem("SGD" & vbTab & vbTab & ":" & vbTab & SGD)
        ExportList &= vbNewLine & "SGD" & vbTab & vbTab & ":" & vbTab & SGD
        FlatListBox1.AddItem("THB" & vbTab & vbTab & ":" & vbTab & THB)
        ExportList &= vbNewLine & "THB" & vbTab & vbTab & ":" & vbTab & THB
        FlatListBox1.AddItem("TRY" & vbTab & vbTab & ":" & vbTab & TRY_)
        ExportList &= vbNewLine & "TRY" & vbTab & vbTab & ":" & vbTab & TRY_
        FlatListBox1.AddItem("USD" & vbTab & vbTab & ":" & vbTab & USD)
        ExportList &= vbNewLine & "USD" & vbTab & vbTab & ":" & vbTab & USD
        FlatListBox1.AddItem("ZAR" & vbTab & vbTab & ":" & vbTab & ZAR)
        ExportList &= vbNewLine & "ZAR" & vbTab & vbTab & ":" & vbTab & ZAR
        FlatListBox1.AddItem("BTC" & vbTab & vbTab & ":" & vbTab & CCRBTC)
        ExportList &= vbNewLine & "BTC" & vbTab & vbTab & ":" & vbTab & CCRBTC


    End Sub

    Dim ExportList As String
    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Dim sa As New SaveFileDialog
        With sa
            .Filter = "Text|*.txt"
            .Title = "Export To"
            .ShowDialog()
            If .FileName <> "" Then
                Using outputFile As New StreamWriter(.OpenFile)
                    outputFile.WriteLine(ExportList)
                End Using
            End If
        End With
    End Sub

    Private Sub s(sender As Object, e As EventArgs) Handles FlatComboBox1.SelectedIndexChanged
        My.Settings.DefualtCurrency = FlatComboBox1.SelectedItem
        My.Settings.Save()
    End Sub

    Private Sub FlatCheckBox2_CheckedChanged(sender As Object) Handles FlatCheckBox2.CheckedChanged
        TopMost = FlatCheckBox2.Checked
    End Sub

    Dim FResize
    Private Sub FlatButton3_MouseDown(sender As Object, e As MouseEventArgs) Handles FlatButton3.MouseDown
        FResize = True
    End Sub

    Private Sub FlatButton3_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton3.MouseMove
        If FResize = True Then
            Me.Width = Windows.Forms.Cursor.Position.X - Me.Location.X
            Me.Height = Windows.Forms.Cursor.Position.Y - Me.Location.Y
        End If
    End Sub

    Private Sub FlatButton3_MouseUp(sender As Object, e As MouseEventArgs) Handles FlatButton3.MouseUp
        FResize = False
    End Sub

    Private Sub FlatClose2_Click(sender As Object, e As EventArgs) Handles FlatClose2.Click
        If StartedUpdate = True Then
            MsgBox("Please Wait", MsgBoxStyle.Information, "Currency")
        Else
            Me.Close()
        End If
    End Sub

    Private Sub FlatCheckBox3_CheckedChanged(sender As Object)
        My.Settings.Save()
    End Sub

    Dim StartedUpdate As Boolean = False
    Private Sub Updatechart()
        Try
            StartedUpdate = True
            Dim PrimaryCR As String = FlatComboBox1.SelectedItem
            Dim SecondaryCR As String = FlatComboBox2.SelectedItem
            Dim DT As DateTime = DateTime.Today
            Dim Day
            Dim Month
            Dim Year
            Dim i As Integer = 0
            Dim i2 As Integer = FlatNumeric1.Value
            FlatLabel4.Text = PrimaryCR & "->" & SecondaryCR
            Do Until i = i2
                DT = DT.AddDays(-1)
                Day = DT.Day
                If Day < 10 Then
                    Day = "0" & Day
                End If
                Month = DT.Month
                If Month < 10 Then
                    Month = "0" & Month
                End If
                Year = DT.Year
                'MsgBox("http://api.fixer.io/" & Year & "-" & Month & "-" & Day & "?base=" & FlatComboBox1.SelectedItem)
                Dim API As String = "http://api.fixer.io/" & Year & "-" & Month & "-" & Day & "?base=" & PrimaryCR
                'Clipboard.SetText(API)
                Dim Get30DayChart As String = New System.Net.WebClient().DownloadString(API)
                Dim CRData As Decimal = SharedCode.getdatainbetween(Get30DayChart, Chr(34) & SecondaryCR & Chr(34) & ":", ",")

                Chart1.Series("SecondaryCR").Points.AddXY(Day & "/" & Month & "/" & Year, CRData)
                i = i + 1
            Loop
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "Currency")
        End Try
        StartedUpdate = False
    End Sub


    Private Sub FlatComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles FlatComboBox2.SelectedIndexChanged
        My.Settings.SecondaryCurrency = FlatComboBox2.SelectedItem
        My.Settings.Save()
    End Sub

    Private Sub FlatButton5_Click(sender As Object, e As EventArgs) Handles FlatButton5.Click
        If StartedUpdate = True Then
            MsgBox("Please Wait", MsgBoxStyle.Information, "Currency")
        Else
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf Updatechart)
            thread.Start()
        End If
    End Sub

    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click
        FlatNumeric1.Value += 10
    End Sub

    Private Sub FlatButton6_Click(sender As Object, e As EventArgs) Handles FlatButton6.Click
        FlatNumeric1.Value -= 10
    End Sub

    Private Sub FlatButton8_Click(sender As Object, e As EventArgs) Handles FlatButton8.Click
        FlatNumeric1.Value += 100
    End Sub

    Private Sub FlatButton7_Click(sender As Object, e As EventArgs) Handles FlatButton7.Click
        FlatNumeric1.Value -= 100
    End Sub
End Class
