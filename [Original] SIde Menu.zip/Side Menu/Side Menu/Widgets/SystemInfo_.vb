﻿Public Class SystemInfo_
    Private Sub SystemInfo__Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GrabSetup.Start()
        GrabValue.Start()
    End Sub

    Dim CPU As Integer
    Dim RAMVistaAnd7 As Integer
    Dim RAMXP As Integer
    Private Sub GrabValue_Tick(sender As Object, e As EventArgs) Handles GrabValue.Tick
        'CPU
        CPU = PerformanceCounterCPUTotal.NextValue
        'RAM
        Dim Major As String = Environment.OSVersion.Version.Major.ToString
        Dim Minor As String = Environment.OSVersion.Version.Minor.ToString
        If Major + "." + Minor = "6.0" Then
            RAMVistaAnd7 = PerformanceCounterRAMVistaAnd7.NextValue
            RAMVistaAnd7 = 100 - (PerformanceCounterRAMVistaAnd7.NextValue / Convert.ToInt32(My.Computer.Info.TotalPhysicalMemory / 1048576)) * 100
            Chart1.Series("RAM").Points.AddY(RAMVistaAnd7)
        ElseIf Major + "." + Minor = "6.1" Then
            RAMVistaAnd7 = PerformanceCounterRAMVistaAnd7.NextValue
            RAMVistaAnd7 = 100 - (PerformanceCounterRAMVistaAnd7.NextValue / Convert.ToInt32(My.Computer.Info.TotalPhysicalMemory / 1048576)) * 100
            Chart1.Series("RAM").Points.AddY(RAMVistaAnd7)
        Else
            RAMXP = PerformanceCounterRamXP.NextValue
            Chart1.Series("RAM").Points.AddY(RAMXP)
        End If


        Chart1.Series("CPU").Points.AddY(CPU)
    End Sub

    Private Sub GrabSetup_Tick(sender As Object, e As EventArgs) Handles GrabSetup.Tick
        'CPU Setup
        If FlatProgressBar2.Value < CPU Then
            FlatProgressBar2.Value += 1
        ElseIf FlatProgressBar2.Value > CPU Then
            FlatProgressBar2.Value -= 1
        End If
        'CPUTotalPrecent.Text = FlatProgressBar2.Value.ToString + "%"
        'RAM Setup 
        Dim Major As String = Environment.OSVersion.Version.Major.ToString
        Dim Minor As String = Environment.OSVersion.Version.Minor.ToString
        If Major + "." + Minor = "6.0" Then
            'Vista
            If FlatProgressBar1.Value < RAMVistaAnd7 Then
                FlatProgressBar1.Value += 1
            ElseIf FlatProgressBar1.Value > RAMVistaAnd7 Then
                FlatProgressBar1.Value -= 1
            End If
            'RAMPrecent.Text = FlatProgressBar1.Value.ToString + "%"
        ElseIf Major + "." + Minor = "6.1" Then
            'Windows 7
            If FlatProgressBar1.Value < RAMVistaAnd7 Then
                FlatProgressBar1.Value += 1
            ElseIf FlatProgressBar1.Value > RAMVistaAnd7 Then
                FlatProgressBar1.Value -= 1
            End If
            'RAMPrecent.Text = FlatProgressBar1.Value.ToString + "%"
        Else
            'XP
            If FlatProgressBar1.Value < RAMXP Then
                FlatProgressBar1.Value += 1
            ElseIf FlatProgressBar1.Value > RAMXP Then
                FlatProgressBar1.Value -= 1
            End If
            'RAMPrecent.Text = FlatProgressBar1.Value.ToString + "%"
        End If
        'Red Lining Setup
        'CPU
        ' If FlatProgressBar2.Value >= 65 Then
        'CPUTotalPrecent.ForeColor = Color.Lime
        'Else
        'CPUTotalPrecent.ForeColor = Color.Lime
        'End If
        'RAM
        ' Dim Value As String = FlatProgressBar1.Value.ToString
        'If Value >= 65 Then
        'RAMPrecent.ForeColor = Color.Lime
        'Else
        'RAMPrecent.ForeColor = Color.Lime
        'End If
    End Sub

    Dim FResize As Boolean
    Private Sub FlatButton1_MouseDown(sender As Object, e As MouseEventArgs) Handles FlatButton1.MouseDown
        FResize = True
    End Sub

    Private Sub FlatButton1_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton1.MouseMove
        If FResize = True Then
            Me.Width = Windows.Forms.Cursor.Position.X - Me.Location.X
            Me.Height = Windows.Forms.Cursor.Position.Y - Me.Location.Y
        End If
    End Sub

    Private Sub FlatButton1_MouseUp(sender As Object, e As MouseEventArgs) Handles FlatButton1.MouseUp
        FResize = False
    End Sub

    Private Sub FlatCheckBox1_CheckedChanged(sender As Object) Handles FlatCheckBox1.CheckedChanged
        TopMost = FlatCheckBox1.Checked
    End Sub

    Private Sub FlatClose1_Click(sender As Object, e As EventArgs) Handles FlatClose1.Click
        Me.Close()
    End Sub
End Class