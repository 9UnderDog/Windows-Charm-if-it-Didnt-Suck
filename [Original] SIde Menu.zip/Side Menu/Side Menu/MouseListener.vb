﻿Public Class MouseListener
    Private Sub MouseListener_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CheckForIllegalCrossThreadCalls = False
        'Debug.Show()
        Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height
        Main.Location = New Point(screenWidth, 0)
        Me.Location = New Point(screenWidth - 1, 30)
        Main.Show()
    End Sub

    Dim B1 = 0 : Dim B2 = 0 : Dim B3 = 0 : Dim B4 = 0 : Dim B5 = 0 : Dim B6 = 0 : Dim B7 = 0 : Dim B8 = 0 : Dim B9 = 0

    Private Sub FlatButton1_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton1.MouseMove
        If B1 = 0 Then
            B1 = 1
            ' Debug.FlatLabel3.Text = B1
        End If
    End Sub

    Private Sub FlatButton2_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton2.MouseMove
        If B2 = 0 Then
            B2 = 1
            'Debug.FlatLabel4.Text = B2
        End If
    End Sub

    Private Sub FlatButton3_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton3.MouseMove
        If B3 = 0 Then
            B3 = 1
            'Debug.FlatLabel5.Text = B3
        End If
    End Sub

    Private Sub FlatButton4_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton4.MouseMove
        If B4 = 0 Then
            B4 = 1
            'Debug.FlatLabel6.Text = B4
        End If
    End Sub

    Private Sub FlatButton5_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton5.MouseMove
        If B5 = 0 Then
            B5 = 1
            'Debug.FlatLabel7.Text = B5
        End If
    End Sub

    Private Sub FlatButton6_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton6.MouseMove
        If B6 = 0 Then
            B6 = 1
            'Debug.FlatLabel8.Text = B6
        End If
    End Sub

    Private Sub FlatButton7_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton7.MouseMove
        If B7 = 0 Then
            B7 = 1
            'Debug.FlatLabel9.Text = B7
            CheckCount()
        End If
    End Sub

    Private Sub FlatButton8_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton8.MouseMove
        If B8 = 0 Then
            B8 = 1
            'Debug.FlatLabel10.Text = B8
            CheckCount()
        End If
    End Sub

    Private Sub FlatButton9_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatButton9.MouseMove
        If B9 = 0 Then
            B9 = 1
            'Debug.FlatLabel11.Text = B9
            CheckCount()
        End If
    End Sub

    Private Sub CheckCount()
        If B1 + B2 + B3 + B4 + B5 + B6 + B7 + B8 + B9 > 7 Then
            B1 = 0
            B2 = 0
            B3 = 0
            B4 = 0
            B5 = 0
            B6 = 0
            B7 = 0
            B8 = 0
            B9 = 0
            'Debug.FlatLabel3.Text = 0
            'Debug.FlatLabel4.Text = 0
            'Debug.FlatLabel5.Text = 0
            'Debug.FlatLabel6.Text = 0
            'Debug.FlatLabel7.Text = 0
            'Debug.FlatLabel8.Text = 0
            'Debug.FlatLabel9.Text = 0
            'Debug.FlatLabel10.Text = 0
            'Debug.FlatLabel11.Text = 0
            SharedCode.Slidein(Main, 351)
        Else
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf Timer1)
            thread.Start()
        End If

    End Sub

    Private Sub Timer1()
        Threading.Thread.Sleep(50)
        B1 = 0
        B2 = 0
        B3 = 0
        B4 = 0
        B5 = 0
        B6 = 0
        B7 = 0
        B8 = 0
        B9 = 0
        'Debug.FlatLabel3.Text = 0
        'Debug.FlatLabel4.Text = 0
        'Debug.FlatLabel5.Text = 0
        'Debug.FlatLabel6.Text = 0
        'Debug.FlatLabel7.Text = 0
        'Debug.FlatLabel8.Text = 0
        'Debug.FlatLabel9.Text = 0
        'Debug.FlatLabel10.Text = 0
        'Debug.FlatLabel11.Text = 0
    End Sub

    Private Sub GC_Tick(sender As Object, e As EventArgs) Handles GCTimer.Tick
        GC.Collect()
    End Sub
End Class