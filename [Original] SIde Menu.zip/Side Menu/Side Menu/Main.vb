﻿Imports System.Management
Imports System.Net
Imports System.IO
Imports System.Net.Sockets
Imports System.Runtime.InteropServices

Public Class Main
    'Hide from taskview - note, removes transparency (maybe can still used one mentioned in post?)
    <DllImport("user32.dll",
EntryPoint:="SetWindowLong")>
    Private Shared Function SetWindowLong(ByVal hWnd As IntPtr,
                                     ByVal nIndex As Integer,
                                     ByVal dwNewLong As Integer) _
                                 As Integer
    End Function
    Dim WS_EX_TOOLWINDOW As Integer = &H80
    Dim GWL_EXSTYLE As Integer = -20


    Dim CurrentVersion As String = "BETA"


    '############################################ LOAD ############################################
    Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
    Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height

    Private Sub navweb()
        'WebBrowser1.Navigate("http://undercode.square7.ch/CheckForUpdates/SideMenu.html")
    End Sub

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call SetWindowLong(Me.Handle, GWL_EXSTYLE, WS_EX_TOOLWINDOW)

        RefreshColours()
        If My.Settings.CheckUpdates = True Then
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf navweb)
            thread.Start()
            'MsgBox("checking")
        End If


        Me.Visible = False
        CheckForIllegalCrossThreadCalls = False
        Height = screenHeight
        Me.Location = New Point(screenWidth, 0)
        Time.Width = 351
        Me.Hide()
        RichTextBox2.Text = My.Settings.MemoText
        If PanelSystemInfo.VerticalScroll.Visible = True Then
            FlatButton18.Width = 305
            FlatTextBox24.Width = 305
            FlatTextBox23.Width = 305
            FlatTextBox22.Width = 305
            FlatTextBox21.Width = 305
            FlatTextBox20.Width = 305
            FlatTextBox6.Width = 305
            FlatTextBox7.Width = 305
            FlatTextBox8.Width = 305
            FlatTextBox9.Width = 305
            FlatTextBox10.Width = 305
            FlatTextBox11.Width = 305
            FlatTextBox12.Width = 305
            FlatTextBox13.Width = 305
            FlatTextBox14.Width = 305
            FlatTextBox15.Width = 305
            FlatTextBox16.Width = 305
        End If
        FlatTextBox17.Text = My.Settings.VTAPI
        sh = screenHeight
    End Sub

    Dim wbl As Boolean = True
    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs)

        If wbl = True Then
            wbl = False
            'MsgBox("doc complete")
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf w)
            thread.Start()
        Else
        End If
    End Sub

    Private Sub w()
        ' MsgBox("checking ver")
        Threading.Thread.Sleep(3000)
        'MsgBox("")
        Dim wbs = New System.Net.WebClient().DownloadString("http://undercode.square7.ch/CheckForUpdates/SideMenu.html")
        ' MsgBox(wbs)
        'WebBrowser1.Document.Body.InnerHtml
        'Dim cv = SharedCode.getdatainbetween(wbs, "_Version:", ",")
        If wbs.Contains(CurrentVersion) Then
            'MsgBox("no update")
        Else
            MsgBox("New update available")
        End If
    End Sub

    Private Sub RefreshColours()
        BackColor = Color.FromArgb(My.Settings.BGcolour)
        Dim b As Control
        For Each b In Me.Controls
            If (b.GetType() Is GetType(Panel)) Then
                Dim d As Panel = CType(b, Panel)
                Try
                    Dim c As Control
                    For Each c In d.Controls
                        If (c.GetType() Is GetType(FlatButton)) Then
                            Dim a As FlatButton = CType(c, FlatButton)
                            a.BaseColor = Color.FromArgb(My.Settings.Pcolour)
                            a.Rounded = My.Settings.RoundedButtons
                        End If
                    Next
                Catch
                End Try
                Try
                    Dim c As Control
                    For Each c In d.Controls
                        If (c.GetType() Is GetType(FlatButton)) Then
                            Dim a As FlatButton = CType(c, FlatButton)
                            a.TextColor = Color.FromArgb(My.Settings.BTcolour)
                        End If
                    Next
                Catch
                End Try
                Try
                    Dim c As Control
                    For Each c In d.Controls
                        If (c.GetType() Is GetType(FlatLabel)) Then
                            Dim a As FlatLabel = CType(c, FlatLabel)
                            a.ForeColor = Color.FromArgb(My.Settings.Lcolour)
                        End If
                    Next
                Catch
                End Try
                Try
                    Dim c As Control
                    For Each c In d.Controls
                        If (c.GetType() Is GetType(FlatTextBox)) Then
                            Dim a As FlatTextBox = CType(c, FlatTextBox)
                            a.CustomBaseColor = Color.FromArgb(My.Settings.TBcolour)
                        End If
                    Next
                Catch
                End Try
                Try
                    Dim c As Control
                    For Each c In d.Controls
                        If (c.GetType() Is GetType(FlatTextBox)) Then
                            Dim a As FlatTextBox = CType(c, FlatTextBox)
                            a.TextColor = Color.FromArgb(My.Settings.TTcolour)
                        End If
                    Next
                Catch
                End Try
                Try
                    Dim c As Control
                    For Each c In d.Controls
                        If (c.GetType() Is GetType(ListBox)) Then
                            Dim a As ListBox = CType(c, ListBox)
                            a.BackColor = Color.FromArgb(My.Settings.TBcolour)
                            a.ForeColor = Color.FromArgb(My.Settings.Pcolour)
                        End If
                    Next
                Catch
                End Try
                Try
                    Dim c As Control
                    For Each c In d.Controls
                        If (c.GetType() Is GetType(FlatCheckBox)) Then
                            Dim a As FlatCheckBox = CType(c, FlatCheckBox)
                            a.TextColor = Color.FromArgb(My.Settings.Lcolour)
                            a.BaseColor = Color.FromArgb(My.Settings.TBcolour)
                            a.BackColor = Color.FromArgb(My.Settings.BGcolour)
                            a.BorderColor = Color.FromArgb(My.Settings.Pcolour)
                        End If
                    Next
                Catch
                End Try
            End If
        Next
        StayActive.TextColor = Color.FromArgb(My.Settings.Lcolour)
        StayActive.BaseColor = Color.FromArgb(My.Settings.TBcolour)
        StayActive.BackColor = Color.FromArgb(My.Settings.BGcolour)
        StayActive.BorderColor = Color.FromArgb(My.Settings.Pcolour)
        BGcolour.BaseColor = Color.FromArgb(My.Settings.BGcolour)
        Pcolour.BaseColor = Color.FromArgb(My.Settings.Pcolour)
        BTcolour.BaseColor = Color.FromArgb(My.Settings.BTcolour)
        Lcolour.BaseColor = Color.FromArgb(My.Settings.Lcolour)
        TBcolour.BaseColor = Color.FromArgb(My.Settings.TBcolour)
        TTcolour.BaseColor = Color.FromArgb(My.Settings.TTcolour)
    End Sub

    Private Sub FlatLabel1_Click(sender As Object, e As EventArgs) Handles Time.Click
        ResetPanel()
    End Sub

    Dim sh As Integer
    Dim CT As String
    Private Sub UpdateTime_Tick(sender As Object, e As EventArgs) Handles UpdateTime.Tick
        CT = TimeOfDay.ToString("h:mm:ss tt")
        Dim thread As System.Threading.Thread
        thread = New System.Threading.Thread(AddressOf UpTime)
        thread.Start()
        If screenHeight = sh Then
        Else
            Height = screenHeight
            sh = screenHeight
        End If
    End Sub

    Private Sub UpTime()
        Time.Text = CT
        screenHeight = Screen.PrimaryScreen.Bounds.Height
    End Sub

    Dim soWidth = 351
    Private Sub Main_Deactivate(sender As Object, e As EventArgs) Handles MyBase.Deactivate
        If StayActive.Checked = True Then
        Else
            StopRunner = True
            ResetPanel()
            SharedCode.Slideout(Me, soWidth)
        End If
    End Sub

    Private Sub ResetPanel()
        If PanelMain.Visible = False Then
            'Width = 350
            PanelWidget.Visible = False
            PanelCMD.Visible = False
            PanelMemo.Visible = False
            PanelNetworkTools.Visible = False
            PanelSystemInfo.Visible = False
            PanelVT.Visible = False
            PanelSettings.Visible = False

            PanelMain.Visible = True
            soWidth = 351
            Me.Location = New Point(screenWidth - 351, 0)
            Time.Width = 351
        End If
    End Sub

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        'SharedCode.Slideout(Me)
        PanelMain.Visible = False
        PanelWidget.Visible = True
        'SharedCode.Slidein(Me)
    End Sub

    Private Sub FlatButton11_Click(sender As Object, e As EventArgs) Handles FlatButton11.Click
        WebBrowser_.Show()
    End Sub

    Private Sub FlatButton8_Click(sender As Object, e As EventArgs) Handles FlatButton8.Click
        Currency.Show()
    End Sub

    Private Sub FlatButton7_Click(sender As Object, e As EventArgs) Handles FlatButton7.Click
        SystemInfo_.Show()
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        PanelCMD.Visible = True
        Me.Location = New Point(screenWidth - 451, 0)
        Time.Width = 451
        PanelMain.Visible = False
    End Sub

    Private Sub FlatButton3_Click(sender As Object, e As EventArgs) Handles FlatButton3.Click
        PanelMemo.Visible = True
        PanelMain.Visible = False
    End Sub

    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click
        PanelNetworkTools.Visible = True
        PanelMain.Visible = False
    End Sub

    Private Sub FlatButton5_Click(sender As Object, e As EventArgs) Handles FlatButton5.Click
        PanelSystemInfo.Visible = True
        PanelMain.Visible = False
    End Sub

    Private Sub FlatButton12_Click(sender As Object, e As EventArgs) Handles FlatButton12.Click
        PanelVT.Visible = True
        Me.Location = New Point(screenWidth - 451, 0)
        Time.Width = 451
        '451, 578
        PanelMain.Visible = False
        soWidth = 451
    End Sub

    Private Sub FlatButton6_Click(sender As Object, e As EventArgs) Handles FlatButton6.Click
        PanelSettings.Visible = True
        Me.Location = New Point(screenWidth - 451, 0)
        Time.Width = 451
        PanelMain.Visible = False
        soWidth = 451
    End Sub


    '############################################ CMD ############################################

    Dim handled = False
    Private Sub FlatTextBox1_TextChanged(sender As Object, e As EventArgs) Handles FlatTextBox1.TextChanged
        If handled = True Then
            Exit Sub
        Else
            a.Text = FlatTextBox1.Text
            If a.Text.Contains(vbNewLine) Then
                handled = True
                Dim b = FlatTextBox1.Text.Replace(vbNewLine, "")

                Try
                    cmd.Kill()
                Catch ex As Exception
                End Try
                'textbox1.Clear()
                If b.Contains(" ") Then
                    psi = New ProcessStartInfo(b.Split(" ")(0), b.Split(" ")(1))
                Else
                    psi = New ProcessStartInfo(b$)
                End If
                Dim systemencoding As System.Text.Encoding
                System.Text.Encoding.GetEncoding(Globalization.CultureInfo.CurrentUICulture.TextInfo.OEMCodePage)
                With psi
                    .UseShellExecute = False
                    .RedirectStandardError = True
                    .RedirectStandardOutput = True
                    .RedirectStandardInput = True
                    .CreateNoWindow = True
                    .StandardOutputEncoding = systemencoding
                    .StandardErrorEncoding = systemencoding
                End With
                cmd = New Process With {.StartInfo = psi, .EnableRaisingEvents = True}
                AddHandler cmd.ErrorDataReceived, AddressOf Async_Data_Received
                AddHandler cmd.OutputDataReceived, AddressOf Async_Data_Received
                Try
                    cmd.Start()
                    cmd.BeginOutputReadLine()
                    cmd.BeginErrorReadLine()
                Catch ex As Exception
                    RichTextBox1.AppendText(vbNewLine & "Fatal Error: " & ex.Message)
                End Try

                ctb2()
            End If
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        FlatTextBox1.Text = ""
        handled = False
        Timer1.Stop()
    End Sub

    Dim a As New TextBox

    Private Sub tb()
        a.Multiline = True
    End Sub

    Private Sub ctb2()
        a.Text = ""
        Timer1.Start()
    End Sub

    Private Sub FlatButton9_Click(sender As Object, e As EventArgs) Handles FlatButton9.Click
        RichTextBox1.Text = ""
    End Sub

    Private Sub Async_Data_Received(ByVal sender As Object, ByVal e As DataReceivedEventArgs)
        Me.Invoke(New InvokeWithString(AddressOf Sync_Output), e.Data)
    End Sub
    Private Sub Sync_Output(ByVal text As String)
        RichTextBox1.AppendText(vbNewLine & text)
        RichTextBox1.SelectionStart = RichTextBox1.TextLength
        RichTextBox1.ScrollToCaret()
        'textbox1.ScrollToCaret()
    End Sub

    Private Sub FlatButton10_Click(sender As Object, e As EventArgs) Handles FlatButton10.Click
        Try
            cmd.Kill()
        Catch ex As Exception
        End Try
        'textbox1.Clear()
        If FlatTextBox1.Text.Contains(" ") Then
            psi = New ProcessStartInfo(FlatTextBox1.Text.Split(" ")(0), FlatTextBox1.Text.Split(" ")(1))
        Else
            psi = New ProcessStartInfo(FlatTextBox1.Text$)
        End If
        Dim systemencoding As System.Text.Encoding
        System.Text.Encoding.GetEncoding(Globalization.CultureInfo.CurrentUICulture.TextInfo.OEMCodePage)
        With psi
            .UseShellExecute = False
            .RedirectStandardError = True
            .RedirectStandardOutput = True
            .RedirectStandardInput = True
            .CreateNoWindow = True
            .StandardOutputEncoding = systemencoding
            .StandardErrorEncoding = systemencoding
        End With
        cmd = New Process With {.StartInfo = psi, .EnableRaisingEvents = True}
        AddHandler cmd.ErrorDataReceived, AddressOf Async_Data_Received
        AddHandler cmd.OutputDataReceived, AddressOf Async_Data_Received
        Try
            cmd.Start()
            cmd.BeginOutputReadLine()
            cmd.BeginErrorReadLine()
        Catch ex As Exception
            RichTextBox1.AppendText(vbNewLine & "Fatal Error: " & ex.Message & vbNewLine)
            RichTextBox1.SelectionStart = RichTextBox1.TextLength
            RichTextBox1.ScrollToCaret()
        End Try
        FlatTextBox1.Text = ""
    End Sub

    Private psi As ProcessStartInfo
    Private cmd As Process
    Private Delegate Sub InvokeWithString(ByVal text As String)


    '############################################ Memo ############################################


    Private Sub RichTextBox2_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox2.TextChanged
        My.Settings.MemoText = RichTextBox2.Text
        My.Settings.Save()
    End Sub


    '############################################ NETWORK TOOLS ############################################


    Private Sub FlatButton17_Click(sender As Object, e As EventArgs) Handles FlatButton17.Click
        Try
            Dim Hostname As IPHostEntry = Dns.GetHostByName(FlatTextBox5.Text)
            Dim ip As IPAddress() = Hostname.AddressList
            FlatTextBox2.Text = ip(0).ToString
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "Network Tools")
        End Try
    End Sub

    Private Sub FlatButton16_Click(sender As Object, e As EventArgs) Handles FlatButton16.Click
        StopRunner = False
        'ProgressBar1.Value = 0
        If FlatCheckBox1.Checked = True Then
            FlatCheckBox1.Enabled = False
            ListBox1.Items.Add("---Full Scan---")
            ScanAllPorts.RunWorkerAsync()
            FlatCheckBox1.Enabled = False
            FlatButton2.Enabled = False
        End If
        If FlatCheckBox1.Checked = False Then
            ListBox1.Items.Add("---Scanning: " & FlatTextBox4.Text & "---")
            SinglePortScan.RunWorkerAsync()
        End If
    End Sub

    Private Sub ScanPort(ByVal port As Integer)
        Try
            Dim PClosed As Boolean
            PClosed = True

            Dim tmpClient As New TcpClient()
            Dim tmpEndPoint As New IPEndPoint(IPAddress.Parse(FlatTextBox3.Text), port)
            tmpClient.Connect(tmpEndPoint)
            If tmpClient.Connected = True Then
                ListBox1.Items.Add("Open Port: " & port)
            End If
            tmpClient = Nothing
            tmpEndPoint = Nothing
        Catch ex As Exception
        End Try
    End Sub

    Dim StopRunner As Boolean = False
    Private Sub FlatButton15_Click(sender As Object, e As EventArgs) Handles FlatButton15.Click
        If FlatCheckBox1.Checked = True Then
            FlatButton2.Enabled = True
            StopRunner = True
            FlatLabel14.Text = "Status: Cancelled"
            FlatCheckBox1.Enabled = True
        End If
    End Sub

    Private Sub FlatButton14_Click(sender As Object, e As EventArgs) Handles FlatButton14.Click
        Dim strList(ListBox1.Items.Count) As String
        ListBox1.Items.CopyTo(strList, 0)
        Dim strClip As String = String.Join(vbCrLf, strList)
        Clipboard.SetDataObject(strClip)
    End Sub

    Private Sub FlatButton13_Click(sender As Object, e As EventArgs) Handles FlatButton13.Click
        ListBox1.Items.Clear()
    End Sub

    Private Sub FlatCheckBox1_CheckedChanged(sender As Object) Handles FlatCheckBox1.CheckedChanged
        FlatTextBox4.ReadOnly = FlatCheckBox1.Checked
    End Sub

    Private Sub ScanAllPorts_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles ScanAllPorts.DoWork
        Dim i As Integer
        For i = 1 To 65535
            Threading.Thread.Sleep(20)
            Dim tmpThread As New System.Threading.Thread(AddressOf ScanPort)
            tmpThread.IsBackground = True
            tmpThread.Start(i)
            FlatLabel14.Text = "Status: Scanning Port " & i
            If StopRunner = True Then
                FlatLabel14.Text = "Status: Cancelled"
                Exit Sub
            End If
        Next
        FlatButton2.Enabled = True
        i = Nothing
        FlatLabel14.Text = "Status: Finished"
    End Sub

    Private Sub SinglePortScan_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles SinglePortScan.DoWork
        Dim tmpThread As New System.Threading.Thread(AddressOf ScanPort)
        tmpThread.IsBackground = True
        tmpThread.Start(FlatTextBox4.Text)
        FlatLabel14.Text = "Status: Scanned " & FlatTextBox4.Text
    End Sub


    '############################################ SYSTEM INFO ############################################


    Private Sub FlatButton18_Click(sender As Object, e As EventArgs) Handles FlatButton18.Click
        Try
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf RefreshLabels)
            thread.Start()
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "System Information")
        End Try
        Try
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf GrabExtIP)
            thread.Start()
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "System Information")
        End Try
    End Sub

    Private Sub RefreshLabels()
        Dim bit As String
        Dim VGA As String
        If My.Computer.Registry.LocalMachine.OpenSubKey("Hardware\Description\System\CentralProcessor\0").GetValue("Identifier").ToString.Contains("x86") Then
            bit = "32-bit"
        Else
            bit = "64-bit"
        End If
        FlatTextBox24.Text = (My.Computer.Info.OSFullName.ToString())
        FlatTextBox23.Text = (My.Computer.Info.OSPlatform.ToString())
        FlatTextBox22.Text = (My.Computer.Info.OSVersion.ToString())
        FlatTextBox21.Text = (bit)
        FlatTextBox20.Text = (My.Computer.Name.ToString())
        Dim objWMI As New WMI()
        With objWMI
            FlatTextBox6.Text = (.Manufacturer)
            FlatTextBox7.Text = (.Model)
            'FlatTextBox8.Text = (.OSVersion)
            FlatTextBox8.Text = (.SystemType)
            FlatTextBox9.Text = (.WindowsDirectory)
        End With

        Dim moSearch As New ManagementObjectSearcher("Select * from Win32_Processor")
        Dim moReturn As ManagementObjectCollection = moSearch.Get
        For Each mo As ManagementObject In moReturn
            FlatTextBox10.Text = ((mo("name")))
        Next
        Dim ramsize As Integer
        ramsize = My.Computer.Info.TotalPhysicalMemory / 1024 / 1024
        FlatTextBox11.Text = (ramsize.ToString & "MB RAM")
        Dim WmiSelect As New ManagementObjectSearcher _
        ("root\CIMV2", "SELECT * FROM Win32_VideoController")
        For Each WmiResults As ManagementObject In WmiSelect.Get()
            VGA = WmiResults.GetPropertyValue("Name").ToString
        Next
        FlatTextBox12.Text = (VGA)
        Dim intX As Integer = Windows.Forms.Screen.PrimaryScreen.Bounds.Width
        Dim intY As Integer = Windows.Forms.Screen.PrimaryScreen.Bounds.Height
        FlatTextBox13.Text = (intX & " X " & intY)
        'FlatTextBox16.Text = ("Total Physical Memory: " & (My.Computer.Info.TotalPhysicalMemory.ToString()) '/ 1024 / 1024) & "MB"
        'FlatTextBox17.Text = ("Total Virtual Memory: " & (My.Computer.Info.TotalVirtualMemory.ToString())' / 1024 / 1024) & "MB"
        'FlatTextBox18.Text = ("Available Virtual Memory: " & (My.Computer.Info.AvailableVirtualMemory.ToString())' / 1024 / 1024) & "MB"
        'FlatTextBox19.Text = ("Available Physical Memory: " & (My.Computer.Info.AvailablePhysicalMemory.ToString())' / 1024 / 1024) & "MB"
        'FlatTextBox14.Text = (My.Computer.Network.IsAvailable.ToString())

        Dim ip As IPHostEntry = Dns.GetHostEntry(Dns.GetHostName)
        FlatTextBox15.Text = ip.AddressList.GetValue(0).ToString
        Dim Hostname As IPHostEntry = Dns.GetHostByName("")
        Dim lip As IPAddress() = Hostname.AddressList
        FlatTextBox14.Text = lip(0).ToString
    End Sub

    Private Sub GrabExtIP()
        FlatTextBox16.Text = "Loading"
        'Get IP:
        Dim wclient As New WebClient
        '// Add a user agent header in case the requested URI contains a query.
        wclient.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR1.0.3705;)")
        Dim baseurl As String = "http://checkip.dyndns.org/"
        ' with proxy server only:
        Dim proxy As IWebProxy = WebRequest.GetSystemWebProxy()
        proxy.Credentials = CredentialCache.DefaultNetworkCredentials
        wclient.Proxy = proxy
        Dim data As Stream
        Try
            data = wclient.OpenRead(baseurl)
        Catch ex As Exception
            Exit Sub
        End Try
        Dim reader As StreamReader = New StreamReader(data)
        Dim s As String = reader.ReadToEnd()
        data.Close()
        reader.Close()
        s = s.Replace("<html><head><title>Current IP Check</title></head><body>", "").Replace("</body></html>", "").ToString()
        s = s.Replace("Current IP Address: ", "")
        s = s.Replace(vbNewLine, "")
        FlatTextBox16.Text = s
    End Sub

    '############################################ VIRUS TOTAL SCANNER ############################################

    Dim VListbox As New ListBox
    Private Sub lb(ByVal i)
        VListbox.Items.Add(i)
        FlatListBox1.AddItem(i)
    End Sub

    Private mScanner As VirusTotalScanner
    Private mResults As List(Of ScanResult)
    Private mResultIndex As Integer
    Private mMD5 As String
    Private mSHA256 As String
    Private mSHA512 As String

    Private Sub FlatButton23_Click(sender As Object, e As EventArgs) Handles FlatButton23.Click
        If StayActive.Checked = False Then
            StayActive.Checked = True
            If vbYes = MsgBox("You Will Need An API Key, Get Yours Free At Http://VirusTotal.com. Open Page In Browser?", MsgBoxStyle.YesNo, "VirusTotal Scanner") Then
                Process.Start("http://VirusTotal.com")
                StayActive.Checked = False
            Else
                StayActive.Checked = False
            End If
        Else
            If vbYes = MsgBox("You Will Need An API Key, Get Yours Free At Http://VirusTotal.com. Open Page In Browser?", MsgBoxStyle.YesNo, "VirusTotal Scanner") Then
                Process.Start("http://VirusTotal.com")
            End If
        End If

    End Sub


    Dim Link As String
    Private Sub FlatButton19_Click(sender As Object, e As EventArgs) Handles FlatButton19.Click
        If StayActive.Checked = False Then
            StayActive.Checked = True
            Try
                If IsNothing(mScanner) Then
                    If FlatTextBox17.Text = "" Then
                        MsgBox("You must first enter your API key.", MsgBoxStyle.Exclamation, "VirusTotal Scanner")
                        FlatTextBox17.Focus()
                        Return
                    End If
                    mScanner = New VirusTotalScanner(FlatTextBox17.Text)
                    mScanner.UseTLS = True
                    FlatTextBox17.Enabled = False
                End If
                If VT_FileSelect.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                    FlatTextBox18.Text = VT_FileSelect.FileName
                    mMD5 = FileHasher.GetMD5(FlatTextBox18.Text)
                    mSHA256 = FileHasher.GetSHA256(FlatTextBox18.Text)
                    mSHA512 = FileHasher.GetSHA512(FlatTextBox18.Text)
                    'lb("MD5: " & mMD5)
                    'lblMD52.Text = mMD5
                    'lb("SHA-256: " & mSHA256)
                    'lb("SHA-512: " & mSHA512)
                    'lblSHA2562.Text = mSHA256
                    'lblSHA5122.Text = mSHA512
                    'Link = mScanner.GetPublicFileScanLink(mSHA256)
                    'LinkLabel1.Text = Link
                    'lb("Link: " & Link)
                    'LinkLabel1.Links.Clear()
                    'LinkLabel1.Links.Add(0, Link.Length)
                    'lblLink2.Text = Link
                    'lblLink2.Links.Clear()
                    'lblLink2.Links.Add(0, Link.Length)
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            StayActive.Checked = False
        Else
            Try
                If IsNothing(mScanner) Then
                    If FlatTextBox17.Text = "" Then
                        MsgBox("You must first enter your API key.", MsgBoxStyle.Exclamation, "VirusTotal Scanner")
                        FlatTextBox17.Focus()
                        Return
                    End If
                    mScanner = New VirusTotalScanner(FlatTextBox17.Text)
                    mScanner.UseTLS = True
                    FlatTextBox17.Enabled = False
                End If
                If VT_FileSelect.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                    FlatTextBox18.Text = VT_FileSelect.FileName
                    mMD5 = FileHasher.GetMD5(FlatTextBox18.Text)
                    mSHA256 = FileHasher.GetSHA256(FlatTextBox18.Text)
                    mSHA512 = FileHasher.GetSHA512(FlatTextBox18.Text)
                    'lb("MD5: " & mMD5)
                    'lblMD52.Text = mMD5
                    'lb("SHA-256: " & mSHA256)
                    'lb("SHA-512: " & mSHA512)
                    'lblSHA2562.Text = mSHA256
                    'lblSHA5122.Text = mSHA512
                    'Link = mScanner.GetPublicFileScanLink(mSHA256)
                    'LinkLabel1.Text = Link
                    'lb("Link: " & Link)
                    'LinkLabel1.Links.Clear()
                    'LinkLabel1.Links.Add(0, Link.Length)
                    'lblLink2.Text = Link
                    'lblLink2.Links.Clear()
                    'lblLink2.Links.Add(0, Link.Length)
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub VT_ViewReport_Click(sender As Object, e As EventArgs) Handles ViewReportToolStripMenuItem1.Click
        Try
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf Viewreport)
            thread.Start()
            'prpMain.SelectedObject = Report
        Catch ex As Exception
            'prpMain.SelectedObject = Nothing
            lb("Error: " & ex.Message)
        End Try
        lb(" ")
    End Sub

    Private Sub Viewreport()
        MsgBox("")
        Try
            Dim Report As Report
            Report = mScanner.GetFileReport(mSHA256)
            lb("Viewing Report Of: " & Path.GetFileName(FlatTextBox18.Text))
            lb("Result: " & Report.Positives & " / " & Report.Total & " @ " & Report.ScanDate)
            lb("Link: " & mScanner.GetPublicFileScanLink(mSHA256))
            'lb("Message: " & Report.VerboseMsg)
        Catch ex As Exception
            lb("Error: " & ex.Message)
        End Try
        lb(" ")
    End Sub

    Private Sub VT_SubmitFile_Click(sender As Object, e As EventArgs) Handles ViewReportToolStripMenuItem.Click
        Try
            FlatButton28.Enabled = False
            'FlatButton29.Enabled = False
            lb("Uploading File: " & Path.GetFileName(FlatTextBox18.Text))
            mScanner.SubmitFile(FlatTextBox18.Text)
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf Submit)
            thread.Start()
        Catch ex As Exception
            lb("Error: " & ex.Message)
            FlatButton28.Enabled = True
            ' FlatButton29.Enabled = True
        End Try
        lb(" ")
    End Sub

    Private Sub Submit()
        Try
            Dim ScanTime
            Dim Report As Report
            Report = mScanner.GetFileReport(mSHA256)
            ScanTime = Report.ScanDate.ToString
            lb("File Submitted And Scan Is In Que. This May Take A While " & "Refreshing In: " & "25 Seconds") 'Change1
            lb("Link: " & mScanner.GetPublicFileScanLink(mSHA256))
repeatScan:
            Threading.Thread.Sleep(25000)
            Report = mScanner.GetFileReport(mSHA256)
            If ScanTime = Report.ScanDate Then
                lb("Scan Is Still In Que. Refreshing In: " & "25 Seconds")
                GoTo repeatScan
            Else
                Viewreport()
            End If
            'Dim thread As System.Threading.Thread
            'thread = New System.Threading.Thread(AddressOf Viewreport)
            'thread.Start()
            FlatButton28.Enabled = True
            'FlatButton29.Enabled = True
        Catch ex As Exception
            lb("Error: " & ex.Message)
            FlatButton28.Enabled = True
            '  FlatButton29.Enabled = True
        End Try
        lb(" ")
    End Sub

    Private Sub VT_RescanHash_Click(sender As Object, e As EventArgs) Handles RescanHashToolStripMenuItem.Click
        Try
            FlatButton28.Enabled = False
            '  FlatButton29.Enabled = False
            Dim thread As System.Threading.Thread
            thread = New System.Threading.Thread(AddressOf rescan)
            thread.Start()

        Catch ex As Exception
            'MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "VirusTotal Scanner")
            lb("Error: " & ex.Message)
            lb(" ")
            FlatButton28.Enabled = True
            ' FlatButton29.Enabled = True
        End Try
    End Sub

    Private Sub rescan()
        Try
            mScanner.RescanFile(mSHA256)
            Dim ScanTime As String
            Dim Report As Report
            Report = mScanner.GetFileReport(mSHA256)
            ScanTime = Report.ScanDate

            lb("File Submitted")
            lb("Waiting For Scan To Finish")
            lb("Please Wait (Refreshes 25 Seconds)")

repeatScan:
            Threading.Thread.Sleep(25000)
            Report = mScanner.GetFileReport(mSHA256)

            If ScanTime = Report.ScanDate Then
                GoTo repeatScan
                lb("Scan Still In Que")
            Else
                lb("Scan Completed")
                Viewreport()
            End If
            'Dim thread As System.Threading.Thread
            'thread = New System.Threading.Thread(AddressOf Viewreport)
            'thread.Start()
            FlatButton28.Enabled = True
            '  FlatButton29.Enabled = True
        Catch ex As Exception
            'MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "VirusTotal Scanner")
            lb("Error: " & ex.Message)
            FlatButton28.Enabled = True
            '  FlatButton29.Enabled = True
        End Try
        lb(" ")
    End Sub

    Private Sub VT_Copy_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        Dim strList(VListbox.Items.Count) As String
        VListbox.Items.CopyTo(strList, 0)
        Dim strClip As String = String.Join(vbCrLf, strList)
        Clipboard.SetDataObject(strClip)
    End Sub

    Private Sub VT_Clear_Click(sender As Object, e As EventArgs) Handles ClearToolStripMenuItem.Click
        FlatListBox1.Clear()
        VListbox.Items.Clear()
    End Sub

    Private Sub VT_AllProcessors_Click(sender As Object, e As EventArgs) Handles UploadFilesToolStripMenuItem.Click
        Dim thread As System.Threading.Thread
        thread = New System.Threading.Thread(AddressOf ScanProcesses)
        thread.Start()
    End Sub

    Private Sub ScanProcesses()
        FlatButton28.Enabled = False
        ' FlatButton29.Enabled = False
        mScanner = New VirusTotalScanner(FlatTextBox17.Text)
        mScanner.UseTLS = True
        For Each p As Process In Process.GetProcesses()
            Dim file As String = ""
            Dim name As String = ""

            Try
                Try
                    name = p.Modules(0).ModuleName
                Catch
                    name = p.Id
                End Try
                file = p.Modules(0).FileName
                lb("Uploading: " & name & "  " & file)
                mScanner.SubmitFile(file)
                lb("Uploaded (Waiting 25 Seconds)")
                Threading.Thread.Sleep(25000)
            Catch ex As Exception
                file = "n/a"
                lb("PID: " & name & " - FAILED - " & ex.Message)
            End Try
            lb(" ")
        Next
        'view reports
        For Each p As Process In Process.GetProcesses()
            Dim file As String = ""
            Dim name As String = ""
            Try
                Try
                    name = p.Modules(0).ModuleName
                Catch
                    name = p.Id

                End Try
                file = p.Modules(0).FileName
                lb("Viewing Report " & name & "  " & file)
                mSHA256 = FileHasher.GetSHA256(file)
                'mScanner.SubmitFile(FlatTextBox18.Text)
                Try
                    Dim Report As Report
                    Report = mScanner.GetFileReport(mSHA256)
                    'lb(" ")
                    'lb("View Report")
                    lb("Positives: " & Report.Positives & "/" & Report.Total)
                    'lb("Total: " & Report.Total)
                    lb("Message: " & Report.VerboseMsg)
                    'lb("Scan Date: " & Report.ScanDate & " (UTC)")
                    lb("Link: " & mScanner.GetPublicFileScanLink(mSHA256))
                    lb("(Waiting 25 Seconds)")
                    Threading.Thread.Sleep(25000)
                Catch ex As Exception
                    'MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "VirusTotal Scanner")
                    lb("Error: " & ex.Message)
                End Try

            Catch ex As Exception
                file = "n/a"
                lb("PID: " & name & " - FAILED - " & ex.Message)
            End Try
            lb(" ")
        Next
        lb("Finished")
        FlatButton28.Enabled = True
        ' FlatButton29.Enabled = True
    End Sub

    Private Sub FlatTextBox17_TextChanged(sender As Object, e As EventArgs) Handles FlatTextBox17.TextChanged
        My.Settings.VTAPI = FlatTextBox17.Text
        My.Settings.Save()
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        SharedCode.Slidein(Me, 351)
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Process.Start("https://hackforums.net/showthread.php?tid=3559385")
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Process.Start("https://hackforums.net/member.php?action=profile&uid=3339627")
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Process.Start("https://github.com/omegatechware/VirusTotal.VB.NET")
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        Process.Start("http://fixer.io/")
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        Process.Start("http://www.coindesk.com/api/")
    End Sub

    Dim ReturnTrue As Boolean = False
    Private Sub BGcolour_Click(sender As Object, e As EventArgs) Handles BGcolour.Click
        Dim a
        If StayActive.Checked = False Then
            StayActive.Checked = True
            a = UpdateColour(BGcolour).ToArgb()
            StayActive.Checked = False
        Else
            StayActive.Checked = True
            a = UpdateColour(BGcolour).ToArgb()
            StayActive.Checked = False
        End If
        If ReturnTrue = True Then
            My.Settings.BGcolour = a
            My.Settings.Save()
            ReturnTrue = False
        End If
    End Sub

    Private Function UpdateColour(ByVal btn As FlatButton) As Color
        Dim cDialog As New ColorDialog()
        cDialog.Color = btn.BaseColor
        If (cDialog.ShowDialog() = DialogResult.OK) Then
            btn.Enabled = True
            btn.BaseColor = cDialog.Color
            ReturnTrue = True
            Return cDialog.Color
        End If
    End Function

    Private Sub FlatCheckBox2_CheckedChanged(sender As Object) Handles FlatCheckBox2.CheckedChanged
        My.Settings.RoundedButtons = FlatCheckBox2.Checked
        My.Settings.Save()
    End Sub

    Private Sub FlatButton27_Click(sender As Object, e As EventArgs) Handles FlatButton27.Click
        RefreshColours()
    End Sub

    Private Sub Pcolour_Click(sender As Object, e As EventArgs) Handles Pcolour.Click
        Dim a
        If StayActive.Checked = False Then
            StayActive.Checked = True
            a = UpdateColour(Pcolour).ToArgb()
            StayActive.Checked = False
        Else
            StayActive.Checked = True
            a = UpdateColour(Pcolour).ToArgb()
            StayActive.Checked = False
        End If
        If ReturnTrue = True Then
            My.Settings.Pcolour = a
            My.Settings.Save()
            ReturnTrue = False
        End If
    End Sub

    Private Sub BTcolour_Click(sender As Object, e As EventArgs) Handles BTcolour.Click
        Dim a
        If StayActive.Checked = False Then
            StayActive.Checked = True
            a = UpdateColour(BTcolour).ToArgb()
            StayActive.Checked = False
        Else
            StayActive.Checked = True
            a = UpdateColour(BTcolour).ToArgb()
            StayActive.Checked = False
        End If
        If ReturnTrue = True Then
            My.Settings.BTcolour = a
            My.Settings.Save()
            ReturnTrue = False
        End If
    End Sub

    Private Sub Lcolour_Click(sender As Object, e As EventArgs) Handles Lcolour.Click
        Dim a
        If StayActive.Checked = False Then
            StayActive.Checked = True
            a = UpdateColour(Lcolour).ToArgb()
            StayActive.Checked = False
        Else
            StayActive.Checked = True
            a = UpdateColour(Lcolour).ToArgb()
            StayActive.Checked = False
        End If
        If ReturnTrue = True Then
            My.Settings.Lcolour = a
            My.Settings.Save()
            ReturnTrue = False
        End If
    End Sub

    Private Sub TBcolour_Click(sender As Object, e As EventArgs) Handles TBcolour.Click
        Dim a
        If StayActive.Checked = False Then
            StayActive.Checked = True
            a = UpdateColour(TBcolour).ToArgb()
            StayActive.Checked = False
        Else
            StayActive.Checked = True
            a = UpdateColour(TBcolour).ToArgb()
            StayActive.Checked = False
        End If
        If ReturnTrue = True Then
            My.Settings.TBcolour = a
            My.Settings.Save()
            ReturnTrue = False
        End If
    End Sub

    Private Sub TTcolour_Click(sender As Object, e As EventArgs) Handles TTcolour.Click
        Dim a
        If StayActive.Checked = False Then
            StayActive.Checked = True
            a = UpdateColour(TTcolour).ToArgb()
            StayActive.Checked = False
        Else
            StayActive.Checked = True
            a = UpdateColour(TTcolour).ToArgb()
            StayActive.Checked = False
        End If
        If ReturnTrue = True Then
            My.Settings.BTcolour = a
            My.Settings.Save()
            ReturnTrue = False
        End If
    End Sub

    Private Sub FlatCheckBox4_CheckedChanged(sender As Object) Handles FlatCheckBox4.CheckedChanged
        My.Settings.CheckUpdates = FlatCheckBox4.Checked
        My.Settings.Save()
    End Sub

    Private Sub FlatCheckBox3_CheckedChanged(sender As Object) Handles FlatCheckBox3.CheckedChanged
        My.Settings.WinStart = FlatCheckBox3.Checked
        If FlatCheckBox3.Checked = True Then
            Try
                My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).SetValue(Application.ProductName, Application.ExecutablePath)
            Catch ex As Exception
                MsgBox("Please close and grant Administrator and try again")
            End Try
        Else
            Try
                My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).DeleteValue(Application.ProductName)
            Catch
                MsgBox("Please close and grant Administrator and try again")
            End Try
        End If
    End Sub

    Private Sub FlatButton28_Click(sender As Object, e As EventArgs) Handles FlatButton28.Click
        Me.Menu_VTScan.Show(Me.FlatButton28, Me.FlatButton28.PointToClient(Cursor.Position))
    End Sub

    Private Sub FlatButton29_Click(sender As Object, e As EventArgs) Handles FlatButton29.Click
        Me.Menu_VTData.Show(Me.FlatButton29, Me.FlatButton29.PointToClient(Cursor.Position))
    End Sub
End Class



Public Class WMI
    Private objOS As Management.ManagementObjectSearcher
    Private objCS As Management.ManagementObjectSearcher
    Private objMgmt As Management.ManagementObject
    Private m_strComputerName As String
    Private m_strManufacturer As String
    Private m_StrModel As String
    Private m_strOSName As String
    Private m_strOSVersion As String
    Private m_strSystemType As String
    Private m_strTPM As String
    Private m_strWindowsDir As String
    Public Sub New()
        objOS = New Management.ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem")
        objCS = New Management.ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystem")
        For Each objMgmt In objOS.Get
            m_strOSName = objMgmt("name").ToString()
            m_strOSVersion = objMgmt("version").ToString()
            m_strComputerName = objMgmt("csname").ToString()
            m_strWindowsDir = objMgmt("windowsdirectory").ToString()
        Next
        For Each objMgmt In objCS.Get
            m_strManufacturer = objMgmt("manufacturer").ToString()
            m_StrModel = objMgmt("model").ToString()
            m_strSystemType = objMgmt("systemtype").ToString
            m_strTPM = objMgmt("totalphysicalmemory").ToString()
        Next
    End Sub
    Public ReadOnly Property ComputerName()
        Get
            ComputerName = m_strComputerName
        End Get
    End Property
    Public ReadOnly Property Manufacturer()
        Get
            Manufacturer = m_strManufacturer
        End Get
    End Property
    Public ReadOnly Property Model()
        Get
            Model = m_StrModel
        End Get
    End Property
    Public ReadOnly Property OsName()
        Get
            OsName = m_strOSName
        End Get
    End Property
    Public ReadOnly Property OSVersion()
        Get
            OSVersion = m_strOSVersion
        End Get
    End Property
    Public ReadOnly Property SystemType()
        Get
            SystemType = m_strSystemType
        End Get
    End Property
    Public ReadOnly Property TotalPhysicalMemory()
        Get
            TotalPhysicalMemory = m_strTPM
        End Get
    End Property
    Public ReadOnly Property WindowsDirectory()
        Get
            WindowsDirectory = m_strWindowsDir
        End Get
    End Property
End Class