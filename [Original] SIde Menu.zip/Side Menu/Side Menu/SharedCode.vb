﻿Imports System.IO
Imports System.Net
Imports System.Security.Cryptography
Imports System.Text
Imports System.Threading.Tasks

Public Class SharedCode
    Public Shared Async Sub Slidein(ByVal F As Form, s As Integer, Optional speed As Integer = 0)
        F.SuspendLayout()
        Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        For i = 0 To s
            Await Task.Delay(speed)
            F.Location = New Point(screenWidth - i, 0)
        Next

        F.ResumeLayout()
        F.Select()
        F.Focus()
        F.Activate()
    End Sub



    Public Shared Sub Slideout(ByVal F As Form, s As Integer)
        For i = 0 To s
            Threading.Thread.Sleep(3)
            F.Location = New Point(F.Location.X + i, 0)
        Next
    End Sub

    Public Shared Function AES_Encrypt(ByVal input As String, ByVal Optional pass As String = "Password") As String
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim encrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = System.Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateEncryptor
            Dim Buffer As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(input)
            encrypted = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return encrypted
        Catch ex As Exception
        End Try
    End Function

    Public Shared Function AES_Decrypt(ByVal input As String, ByVal Optional pass As String = "Password") As String
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = System.Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
        End Try
    End Function

    Public Shared Function SHA512(ByVal P As String)
        Dim a() As Byte = Encoding.UTF8.GetBytes(P)
        Dim b As Byte()
        Dim c As New SHA512Managed
        b = c.ComputeHash(a)
        Dim d As String = Convert.ToBase64String(b)
        Return d
    End Function

    Public Shared Function GetPublicIP()
        'Get IP:
        Dim wclient As New WebClient
        '// Add a user agent header in case the requested URI contains a query.
        wclient.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR1.0.3705;)")
        Dim baseurl As String = "http://checkip.dyndns.org/"
        ' with proxy server only:
        Dim proxy As IWebProxy = WebRequest.GetSystemWebProxy()
        proxy.Credentials = CredentialCache.DefaultNetworkCredentials
        wclient.Proxy = proxy
        Dim data As Stream
        Try
            data = wclient.OpenRead(baseurl)
        Catch ex As Exception
            Return "Error: " & ex.Message
        End Try
        Dim reader As StreamReader = New StreamReader(data)
        Dim s As String = reader.ReadToEnd()
        data.Close()
        reader.Close()
        s = s.Replace("<html><head><title>Current IP Check</title></head><body>", "").Replace("</body></html>", "").ToString()
        s = s.Replace("Current IP Address: ", "")
        s = s.Replace(vbNewLine, "")
        Return s
    End Function

    Public Shared Function getdatainbetween(ByVal input, T1, T2)
        Dim s = input
        s = s.Substring(s.IndexOf(T1) + T1.length)
        s = s.Substring(0, s.IndexOf(T2))

        Return s
    End Function
End Class
